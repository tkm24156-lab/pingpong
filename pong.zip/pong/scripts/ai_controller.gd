class_name AIController
extends Node
## Difficulty-driven paddle brain. It predicts only while the ball approaches.

var profile: Dictionary = {}
var target_y := 360.0
var _reaction_left := 0.0
var _hesitation_left := 0.0
var _center_y := 380.0
var _rng := RandomNumberGenerator.new()
var _last_ball_vx := 0.0
var _time := 0.0


func setup(difficulty_profile: Dictionary, center_y: float) -> void:
	profile = difficulty_profile.duplicate(true)
	_center_y = center_y
	target_y = center_y
	_rng.randomize()


func update_ai(delta: float, ball: PongBall, paddle: Paddle, bounds: Vector2) -> float:
	_time += delta
	_reaction_left -= delta
	_hesitation_left = maxf(0.0, _hesitation_left - delta)
	var ball_incoming := ball.velocity.x > 0.0 and ball.is_active
	if ball_incoming and _last_ball_vx <= 0.0:
		_reaction_left = float(profile.get("reaction_time", 0.2)) * _rng.randf_range(0.7, 1.2)
		_hesitation_left = 0.0
	_last_ball_vx = ball.velocity.x

	if not ball_incoming:
		var drift := sin(_time * 1.3) * 28.0
		target_y = _center_y + drift
		return target_y

	if _hesitation_left > 0.0:
		return target_y

	if _reaction_left > 0.0:
		return target_y

	var reaction_time := float(profile.get("reaction_time", 0.2))
	_reaction_left = reaction_time * _rng.randf_range(0.8, 1.25)
	if _rng.randf() < float(profile.get("hesitation_chance", 0.0)):
		_hesitation_left = _rng.randf_range(0.08, 0.24)
		return target_y

	var predicted := _predict_y(ball, paddle.position.x - 24.0, bounds)
	var error := float(profile.get("error_px", 24.0))
	predicted += _rng.randf_range(-error, error)
	# Easy AI intentionally lags behind fast balls.
	if not bool(profile.get("prediction", false)):
		predicted = lerpf(predicted, ball.position.y, 0.65)
	target_y = clampf(predicted, bounds.x, bounds.y)
	return target_y


func _predict_y(ball: PongBall, target_x: float, bounds: Vector2) -> float:
	if ball.velocity.x <= 0.0001:
		return ball.position.y
	var time_to_reach := (target_x - ball.position.x) / ball.velocity.x
	if time_to_reach < 0.0:
		return ball.position.y
	var predicted := ball.position.y + ball.velocity.y * time_to_reach
	if not bool(profile.get("prediction", false)):
		return clampf(predicted, bounds.x, bounds.y)
	# Reflect across top/bottom walls, accounting for the ball's radius.
	var top := bounds.x - 22.0
	var bottom := bounds.y + 22.0
	var span := bottom - top
	if span <= 0.0:
		return clampf(predicted, top, bottom)
	predicted = fposmod(predicted - top, span * 2.0)
	if predicted > span:
		predicted = span * 2.0 - predicted
	return top + predicted


func should_smash() -> bool:
	return _rng.randf() < float(profile.get("smash_chance", 0.0))


func should_guard() -> bool:
	return _rng.randf() < float(profile.get("guard_chance", 0.0))
