class_name PauseMenu
extends CanvasLayer
## Pause overlay. The match controller owns the tree pause state.

signal resume_requested
signal restart_requested
signal menu_requested
signal sound_toggled

var _root: Control
var _panel: PanelContainer
var _sound_button: Button
var _resume_button: Button
var _open := false


func _ready() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _build() -> void:
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.theme = ArcadeTheme.make_theme()
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.025, 0.08, 0.76)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	_root.add_child(dim)

	_panel = PanelContainer.new()
	_panel.theme_type_variation = "ModalPanel"
	_panel.position = Vector2(390, 120)
	_panel.custom_minimum_size = Vector2(500, 480)
	_root.add_child(_panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 40)
	margin.add_theme_constant_override("margin_right", 40)
	margin.add_theme_constant_override("margin_top", 30)
	margin.add_theme_constant_override("margin_bottom", 30)
	_panel.add_child(margin)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	margin.add_child(column)

	var kicker := Label.new()
	kicker.text = "MATCH PAUSED"
	kicker.theme_type_variation = "PillLabel"
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	kicker.add_theme_color_override("font_color", ArcadeTheme.TEAL)
	column.add_child(kicker)

	var title := Label.new()
	title.text = "TIME OUT!"
	title.theme_type_variation = "TitleLabel"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 58)
	column.add_child(title)

	var divider := HSeparator.new()
	var divider_style := StyleBoxLine.new()
	divider_style.color = Color(1, 1, 1, 0.12)
	divider_style.thickness = 2
	divider.add_theme_stylebox_override("separator", divider_style)
	column.add_child(divider)

	_resume_button = _make_button("RESUME", "PrimaryButton")
	_resume_button.pressed.connect(func() -> void: resume_requested.emit())
	column.add_child(_resume_button)

	var restart := _make_button("RESTART MATCH", "SecondaryButton")
	restart.pressed.connect(func() -> void: restart_requested.emit())
	column.add_child(restart)

	_sound_button = _make_button("SOUND: ON", "GhostButton")
	_sound_button.pressed.connect(_on_sound_pressed)
	column.add_child(_sound_button)

	var quit := _make_button("QUIT TO MENU", "GhostButton")
	quit.add_theme_color_override("font_color", ArcadeTheme.CORAL)
	quit.pressed.connect(func() -> void: menu_requested.emit())
	column.add_child(quit)

	var hint := Label.new()
	hint.text = "W/S MOVE   •   SPACE SMASH   •   SHIFT GUARD   •   ESC RESUME"
	hint.theme_type_variation = "MutedLabel"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 11)
	column.add_child(hint)


func _make_button(text: String, variation: String) -> Button:
	var button := Button.new()
	button.text = text
	button.theme_type_variation = variation
	button.custom_minimum_size = Vector2(0, 54)
	button.add_theme_font_size_override("font_size", 22)
	return button


func open() -> void:
	_open = true
	visible = true
	_root.modulate.a = 0.0
	_panel.scale = Vector2(0.88, 0.88)
	_panel.pivot_offset = Vector2(250, 240)
	var tween := create_tween().set_parallel(true)
	tween.tween_property(_root, "modulate:a", 1.0, 0.16)
	tween.tween_property(_panel, "scale", Vector2.ONE, 0.28).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_update_sound_label()
	_resume_button.grab_focus()


func close() -> void:
	_open = false
	visible = false


func is_open() -> bool:
	return _open


func _on_sound_pressed() -> void:
	sound_toggled.emit()
	_update_sound_label()


func refresh_sound_label() -> void:
	_update_sound_label()


func _update_sound_label() -> void:
	if _sound_button:
		_sound_button.text = "SOUND: ON" if GameState.sound_enabled else "SOUND: OFF"
