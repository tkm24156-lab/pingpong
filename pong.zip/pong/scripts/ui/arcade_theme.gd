class_name ArcadeTheme
extends RefCounted
## Shared palette, fonts, and UI theme for every screen.

const DISPLAY_FONT := preload("res://assets/fonts/LuckiestGuy-Regular.ttf")
const BODY_FONT := preload("res://assets/fonts/Nunito-Variable.ttf")

const INK := Color("#10122B")
const INK_DEEP := Color("#0A0C1C")
const INK_SOFT := Color("#1A1D42")
const PANEL := Color("#151938")
const PAPER := Color("#FFF7E8")
const MUTED := Color("#A7B0D6")
const YELLOW := Color("#FFD447")
const YELLOW_HOT := Color("#FFE47E")
const CORAL := Color("#FF5D73")
const TEAL := Color("#2EE6C8")
const BLUE := Color("#5CC8FF")
const GREEN := Color("#61E8A8")
const PINK := Color("#FF8FB1")
const PURPLE := Color("#8E7DFF")


static func make_theme() -> Theme:
	var theme := Theme.new()
	theme.default_font = BODY_FONT
	theme.default_font_size = 20

	# Labels -----------------------------------------------------------------
	theme.set_type_variation("DisplayLabel", "Label")
	theme.set_font("font", "DisplayLabel", DISPLAY_FONT)
	theme.set_font_size("font_size", "DisplayLabel", 42)
	theme.set_color("font_color", "DisplayLabel", PAPER)
	theme.set_color("font_outline_color", "DisplayLabel", INK_DEEP)
	theme.set_constant("outline_size", "DisplayLabel", 8)

	theme.set_type_variation("TitleLabel", "Label")
	theme.set_font("font", "TitleLabel", DISPLAY_FONT)
	theme.set_font_size("font_size", "TitleLabel", 52)
	theme.set_color("font_color", "TitleLabel", YELLOW)
	theme.set_color("font_outline_color", "TitleLabel", INK_DEEP)
	theme.set_constant("outline_size", "TitleLabel", 10)

	theme.set_type_variation("LogoLabel", "Label")
	theme.set_font("font", "LogoLabel", DISPLAY_FONT)
	theme.set_font_size("font_size", "LogoLabel", 124)
	theme.set_color("font_color", "LogoLabel", YELLOW)
	theme.set_color("font_outline_color", "LogoLabel", INK_DEEP)
	theme.set_constant("outline_size", "LogoLabel", 18)
	theme.set_constant("shadow_offset_x", "LogoLabel", 0)
	theme.set_constant("shadow_offset_y", "LogoLabel", 10)
	theme.set_color("font_shadow_color", "LogoLabel", Color(0, 0, 0, 0.35))

	theme.set_type_variation("ScoreLabel", "Label")
	theme.set_font("font", "ScoreLabel", DISPLAY_FONT)
	theme.set_font_size("font_size", "ScoreLabel", 62)
	theme.set_color("font_color", "ScoreLabel", PAPER)
	theme.set_color("font_outline_color", "ScoreLabel", INK_DEEP)
	theme.set_constant("outline_size", "ScoreLabel", 8)

	theme.set_type_variation("MutedLabel", "Label")
	theme.set_font("font", "MutedLabel", BODY_FONT)
	theme.set_font_size("font_size", "MutedLabel", 15)
	theme.set_color("font_color", "MutedLabel", MUTED)

	theme.set_type_variation("PillLabel", "Label")
	theme.set_font("font", "PillLabel", DISPLAY_FONT)
	theme.set_font_size("font_size", "PillLabel", 17)
	theme.set_color("font_color", "PillLabel", TEAL)

	theme.set_type_variation("ToastLabel", "Label")
	theme.set_font("font", "ToastLabel", DISPLAY_FONT)
	theme.set_font_size("font_size", "ToastLabel", 74)
	theme.set_color("font_color", "ToastLabel", YELLOW)
	theme.set_color("font_outline_color", "ToastLabel", INK_DEEP)
	theme.set_constant("outline_size", "ToastLabel", 14)
	theme.set_constant("shadow_offset_x", "ToastLabel", 0)
	theme.set_constant("shadow_offset_y", "ToastLabel", 8)
	theme.set_color("font_shadow_color", "ToastLabel", Color(0, 0, 0, 0.35))

	# Panels -----------------------------------------------------------------
	theme.set_type_variation("GlassPanel", "PanelContainer")
	theme.set_stylebox("panel", "GlassPanel", _style(Color(0.055, 0.063, 0.15, 0.88), Color(1, 1, 1, 0.10), 26, 2, 18))
	theme.set_type_variation("HudPanel", "PanelContainer")
	theme.set_stylebox("panel", "HudPanel", _style(Color(0.067, 0.078, 0.19, 0.94), Color(1, 0.83, 0.28, 0.28), 20, 2, 12))
	theme.set_type_variation("ModalPanel", "PanelContainer")
	theme.set_stylebox("panel", "ModalPanel", _style(Color("#171A3E"), YELLOW, 30, 4, 26))
	theme.set_type_variation("DarkPanel", "PanelContainer")
	theme.set_stylebox("panel", "DarkPanel", _style(Color(0.055, 0.063, 0.16, 0.93), Color(1, 1, 1, 0.08), 18, 2, 10))

	# Buttons ----------------------------------------------------------------
	_add_button_variation(theme, "PrimaryButton", YELLOW, INK, YELLOW_HOT, Color("#E8B92C"), Color(1, 1, 1, 0.22), 30)
	_add_button_variation(theme, "SecondaryButton", Color("#232851"), PAPER, Color("#30376B"), Color("#1A1E40"), Color(1, 1, 1, 0.16), 22)
	_add_button_variation(theme, "CoralButton", CORAL, Color("#25101A"), Color("#FF7E91"), Color("#D8485D"), Color(1, 1, 1, 0.20), 24)
	_add_button_variation(theme, "GhostButton", Color(0, 0, 0, 0), MUTED, Color(1, 1, 1, 0.10), Color(0, 0, 0, 0.16), Color(0, 0, 0, 0), 18)
	_add_button_variation(theme, "DifficultyButton", Color("#1D2249"), PAPER, Color("#2C3468"), Color("#171B3B"), Color(1, 1, 1, 0.10), 21)
	_add_button_variation(theme, "DifficultySelected", TEAL, INK, Color("#6AF4DC"), Color("#19BFA6"), YELLOW, 21)
	_add_button_variation(theme, "IconButton", Color("#202650"), PAPER, Color("#303A75"), Color("#141733"), Color(1, 1, 1, 0.14), 20)

	theme.set_font("font", "Button", DISPLAY_FONT)
	theme.set_constant("outline_size", "Button", 0)

	# Progress bars ----------------------------------------------------------
	theme.set_type_variation("AbilityBar", "ProgressBar")
	var bar_bg := _style(Color(0.02, 0.025, 0.07, 0.9), Color(1, 1, 1, 0.08), 6, 1, 0)
	var bar_fill := _style(TEAL, Color(0, 0, 0, 0), 6, 0, 0)
	theme.set_stylebox("background", "AbilityBar", bar_bg)
	theme.set_stylebox("fill", "AbilityBar", bar_fill)
	theme.set_font_size("font_size", "AbilityBar", 12)
	theme.set_color("font_color", "AbilityBar", PAPER)

	return theme


static func _add_button_variation(
	theme: Theme,
	variation: String,
	bg: Color,
	fg: Color,
	hover_bg: Color,
	pressed_bg: Color,
	focus_border: Color,
	font_size: int
) -> void:
	theme.set_type_variation(variation, "Button")
	theme.set_font("font", variation, DISPLAY_FONT)
	theme.set_font_size("font_size", variation, font_size)
	theme.set_color("font_color", variation, fg)
	theme.set_color("font_hover_color", variation, fg)
	theme.set_color("font_pressed_color", variation, fg)
	theme.set_color("font_focus_color", variation, fg)
	theme.set_color("font_disabled_color", variation, Color(fg.r, fg.g, fg.b, 0.35))
	theme.set_constant("outline_size", variation, 0)
	var normal := _style(bg, focus_border if focus_border.a > 0.0 else Color(1, 1, 1, 0.0), 17, 3, 8)
	normal.content_margin_left = 22
	normal.content_margin_right = 22
	normal.content_margin_top = 12
	normal.content_margin_bottom = 12
	theme.set_stylebox("normal", variation, normal)
	var hover := normal.duplicate()
	hover.bg_color = hover_bg
	hover.shadow_size = 12
	theme.set_stylebox("hover", variation, hover)
	var pressed := normal.duplicate()
	pressed.bg_color = pressed_bg
	pressed.shadow_size = 3
	pressed.content_margin_top = 15
	pressed.content_margin_bottom = 9
	theme.set_stylebox("pressed", variation, pressed)
	var focus := normal.duplicate()
	focus.bg_color = Color(0, 0, 0, 0)
	focus.border_color = focus_border if focus_border.a > 0.0 else TEAL
	focus.set_border_width_all(3)
	focus.shadow_size = 0
	theme.set_stylebox("focus", variation, focus)
	var disabled := normal.duplicate()
	disabled.bg_color = Color(bg.r, bg.g, bg.b, 0.35)
	theme.set_stylebox("disabled", variation, disabled)


static func _style(
	bg: Color,
	border: Color,
	radius: int,
	border_width: int,
	shadow_size: int
) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border
	style.set_border_width_all(border_width)
	style.set_corner_radius_all(radius)
	style.shadow_color = Color(0.01, 0.012, 0.04, 0.55)
	style.shadow_size = shadow_size
	style.shadow_offset = Vector2(0, maxf(3.0, shadow_size * 0.35))
	style.anti_aliasing = true
	return style


static func panel_style(bg: Color, border: Color, radius: int = 22, border_width: int = 2) -> StyleBoxFlat:
	return _style(bg, border, radius, border_width, 14)


static func keycap_style(accent: Color = YELLOW) -> StyleBoxFlat:
	var style := _style(Color("#FFF2CE"), accent, 7, 2, 2)
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 2
	style.content_margin_bottom = 2
	return style
