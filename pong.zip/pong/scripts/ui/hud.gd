class_name GameHUD
extends CanvasLayer
## Score, match progress, callouts, abilities, and ball-speed readout.

signal pause_pressed

var _root: Control
var _player_name_label: Label
var _ai_name_label: Label
var _player_score_label: Label
var _ai_score_label: Label
var _round_label: Label
var _best_of_label: Label
var _status_label: Label
var _toast: VBoxContainer
var _toast_main: Label
var _toast_sub: Label
var _countdown_label: Label
var _serve_hint: Label
var _player_pips: HBoxContainer
var _ai_pips: HBoxContainer
var _smash_card: AbilityCard
var _guard_card: AbilityCard
var _speed_bar: ProgressBar
var _speed_label: Label
var _toast_tween: Tween
var _toast_reset_tween: Tween
var _countdown_tween: Tween
var _score_tweens := {}


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()


func _build() -> void:
	_root = Control.new()
	_root.name = "HUDRoot"
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.theme = ArcadeTheme.make_theme()
	add_child(_root)

	_build_scoreboard()
	_build_abilities()
	_build_speed_panel()
	_build_center_texts()
	_build_pause_button()


func _build_scoreboard() -> void:
	var panel := PanelContainer.new()
	panel.theme_type_variation = "HudPanel"
	panel.position = Vector2(340, 8)
	panel.custom_minimum_size = Vector2(600, 94)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 7)
	margin.add_theme_constant_override("margin_bottom", 7)
	panel.add_child(margin)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	margin.add_child(row)

	# Player score block.
	var player_box := HBoxContainer.new()
	player_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	player_box.add_theme_constant_override("separation", 8)
	row.add_child(player_box)

	_player_score_label = _make_label("0", "ScoreLabel", 50, ArcadeTheme.TEAL, 70)
	_player_score_label.custom_minimum_size = Vector2(58, 0)
	_player_score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	player_box.add_child(_player_score_label)

	var player_meta := VBoxContainer.new()
	player_meta.add_theme_constant_override("separation", 1)
	player_meta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	player_box.add_child(player_meta)
	_player_name_label = _make_label("MAYA", "DisplayLabel", 17, ArcadeTheme.TEAL, 100)
	_player_name_label.add_theme_constant_override("outline_size", 4)
	player_meta.add_child(_player_name_label)
	_player_pips = _make_pips(ArcadeTheme.TEAL)
	player_meta.add_child(_player_pips)

	# Center match status.
	var center_box := VBoxContainer.new()
	center_box.custom_minimum_size = Vector2(150, 0)
	center_box.alignment = BoxContainer.ALIGNMENT_CENTER
	center_box.add_theme_constant_override("separation", 1)
	row.add_child(center_box)
	_round_label = _make_label("ROUND 1", "DisplayLabel", 18, ArcadeTheme.YELLOW, 150)
	_round_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_round_label.add_theme_constant_override("outline_size", 4)
	center_box.add_child(_round_label)
	_best_of_label = _make_label("BEST OF 3", "MutedLabel", 11, ArcadeTheme.MUTED, 150)
	_best_of_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center_box.add_child(_best_of_label)
	_status_label = _make_label("FIRST TO 11", "MutedLabel", 10, ArcadeTheme.MUTED, 150)
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center_box.add_child(_status_label)

	# AI score block.
	var ai_box := HBoxContainer.new()
	ai_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ai_box.alignment = BoxContainer.ALIGNMENT_END
	ai_box.add_theme_constant_override("separation", 8)
	row.add_child(ai_box)
	var ai_meta := VBoxContainer.new()
	ai_meta.add_theme_constant_override("separation", 1)
	ai_meta.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ai_box.add_child(ai_meta)
	_ai_name_label = _make_label("BOT-9000", "DisplayLabel", 17, ArcadeTheme.CORAL, 100)
	_ai_name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_ai_name_label.add_theme_constant_override("outline_size", 4)
	ai_meta.add_child(_ai_name_label)
	_ai_pips = _make_pips(ArcadeTheme.CORAL)
	_ai_pips.alignment = BoxContainer.ALIGNMENT_END
	ai_meta.add_child(_ai_pips)
	_ai_score_label = _make_label("0", "ScoreLabel", 50, ArcadeTheme.CORAL, 70)
	_ai_score_label.custom_minimum_size = Vector2(58, 0)
	_ai_score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ai_box.add_child(_ai_score_label)


func _build_abilities() -> void:
	var row := HBoxContainer.new()
	row.position = Vector2(20, 656)
	row.add_theme_constant_override("separation", 8)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(row)
	_smash_card = AbilityCard.new()
	_smash_card.setup("SMASH", "SPACE", ArcadeTheme.YELLOW)
	row.add_child(_smash_card)
	_guard_card = AbilityCard.new()
	_guard_card.setup("GUARD", "SHIFT", ArcadeTheme.TEAL)
	row.add_child(_guard_card)


func _build_speed_panel() -> void:
	var panel := PanelContainer.new()
	panel.theme_type_variation = "DarkPanel"
	panel.position = Vector2(1015, 656)
	panel.custom_minimum_size = Vector2(245, 54)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(panel)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 6)
	margin.add_theme_constant_override("margin_bottom", 6)
	panel.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 3)
	margin.add_child(column)
	var header := HBoxContainer.new()
	column.add_child(header)
	var label := _make_label("BALL SPEED", "PillLabel", 12, ArcadeTheme.MUTED, 0)
	label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	label.add_theme_color_override("font_color", ArcadeTheme.MUTED)
	header.add_child(label)
	_speed_label = _make_label("430", "PillLabel", 12, ArcadeTheme.YELLOW, 0)
	_speed_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	header.add_child(_speed_label)
	_speed_bar = ProgressBar.new()
	_speed_bar.theme_type_variation = "AbilityBar"
	_speed_bar.show_percentage = false
	_speed_bar.custom_minimum_size = Vector2(0, 7)
	_speed_bar.max_value = 100.0
	_speed_bar.value = 20.0
	var fill := ArcadeTheme._style(ArcadeTheme.YELLOW, Color(0, 0, 0, 0), 5, 0, 0)
	_speed_bar.add_theme_stylebox_override("fill", fill)
	column.add_child(_speed_bar)


func _build_center_texts() -> void:
	_toast = VBoxContainer.new()
	_toast.position = Vector2(0, 250)
	_toast.custom_minimum_size = Vector2(1280, 0)
	_toast.alignment = BoxContainer.ALIGNMENT_CENTER
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast.modulate.a = 0.0
	_root.add_child(_toast)
	_toast_main = _make_label("POINT!", "ToastLabel", 78, ArcadeTheme.YELLOW, 1280)
	_toast_main.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.add_child(_toast_main)
	_toast_sub = _make_label("", "DisplayLabel", 22, ArcadeTheme.PAPER, 1280)
	_toast_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_sub.add_theme_constant_override("outline_size", 6)
	_toast.add_child(_toast_sub)

	_countdown_label = _make_label("3", "ToastLabel", 130, ArcadeTheme.TEAL, 1280)
	_countdown_label.position = Vector2(0, 310)
	_countdown_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_countdown_label.modulate.a = 0.0
	_countdown_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_countdown_label)

	_serve_hint = _make_label("GET READY", "DisplayLabel", 18, ArcadeTheme.MUTED, 1280)
	_serve_hint.position = Vector2(0, 478)
	_serve_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_serve_hint.add_theme_constant_override("outline_size", 5)
	_serve_hint.modulate.a = 0.0
	_serve_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_serve_hint)


func _build_pause_button() -> void:
	var button := Button.new()
	button.text = "II"
	button.theme_type_variation = "IconButton"
	button.position = Vector2(1228, 18)
	button.custom_minimum_size = Vector2(44, 44)
	button.tooltip_text = "Pause (Esc)"
	button.focus_mode = Control.FOCUS_NONE
	button.pressed.connect(func() -> void: pause_pressed.emit())
	button.add_theme_font_size_override("font_size", 18)
	_root.add_child(button)


func _make_label(text: String, variation: String, size: int, color: Color, width: float) -> Label:
	var label := Label.new()
	label.text = text
	label.theme_type_variation = variation
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	if width > 0.0:
		label.custom_minimum_size = Vector2(width, 0)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label


func _make_pips(color: Color) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	row.custom_minimum_size = Vector2(0, 13)
	for i in 2:
		var pip := Panel.new()
		pip.custom_minimum_size = Vector2(13, 13)
		pip.mouse_filter = Control.MOUSE_FILTER_IGNORE
		pip.set_meta("accent", color)
		pip.set_meta("won", false)
		row.add_child(pip)
	return row


func _refresh_pip(pip: Panel, won: bool, color: Color) -> void:
	var style := StyleBoxFlat.new()
	style.set_corner_radius_all(7)
	style.bg_color = color if won else Color(0.08, 0.09, 0.2, 0.85)
	style.border_color = Color(color.r, color.g, color.b, 0.75 if won else 0.25)
	style.set_border_width_all(2)
	style.shadow_color = Color(color.r, color.g, color.b, 0.28)
	style.shadow_size = 6 if won else 0
	pip.add_theme_stylebox_override("panel", style)


func setup_names(player_name: String, ai_name: String) -> void:
	_player_name_label.text = player_name
	_ai_name_label.text = ai_name


func set_score(player_score: int, ai_score: int, animate: bool = true) -> void:
	_player_score_label.text = str(player_score)
	_ai_score_label.text = str(ai_score)
	if animate:
		_punch_label(_player_score_label)
		_punch_label(_ai_score_label)


func _punch_label(label: Label) -> void:
	var key := label.get_instance_id()
	if _score_tweens.has(key):
		var old: Tween = _score_tweens[key]
		if old and old.is_valid():
			old.kill()
	label.pivot_offset = Vector2(29, 34)
	var tween := create_tween()
	tween.tween_property(label, "scale", Vector2(1.25, 1.25), 0.07)
	tween.tween_property(label, "scale", Vector2.ONE, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_score_tweens[key] = tween


func set_round(round_number: int) -> void:
	_round_label.text = "ROUND %d" % round_number


func set_round_wins(player_rounds: int, ai_rounds: int) -> void:
	var player_pips := _player_pips.get_children()
	for i in player_pips.size():
		_refresh_pip(player_pips[i], i < player_rounds, ArcadeTheme.TEAL)
	var ai_pips := _ai_pips.get_children()
	for i in ai_pips.size():
		_refresh_pip(ai_pips[i], i < ai_rounds, ArcadeTheme.CORAL)


func set_match_status(text: String, color: Color = ArcadeTheme.MUTED) -> void:
	_status_label.text = text
	_status_label.add_theme_color_override("font_color", color)


func update_abilities(smash_ready: bool, smash_active: bool, smash_cooldown: float, smash_total: float, guard_ready: bool, guard_active: bool, guard_cooldown: float, guard_total: float) -> void:
	_smash_card.set_state(smash_ready, smash_active, smash_cooldown, smash_total)
	_guard_card.set_state(guard_ready, guard_active, guard_cooldown, guard_total)


func set_ball_speed(speed: float, max_speed: float) -> void:
	var ratio := clampf(speed / max_speed, 0.0, 1.0)
	_speed_bar.value = lerpf(_speed_bar.value, ratio * 100.0, 0.25)
	_speed_label.text = "%d" % roundi(speed)


func announce(main_text: String, sub_text: String = "", color: Color = ArcadeTheme.YELLOW, hold: float = 0.9) -> void:
	if _toast_tween and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast_main.text = main_text
	_toast_main.add_theme_color_override("font_color", color)
	_toast_sub.text = sub_text
	_toast_sub.visible = sub_text != ""
	_toast.modulate.a = 0.0
	_toast.scale = Vector2(0.82, 0.82)
	_toast.pivot_offset = Vector2(640, 60)
	_toast.visible = true
	_toast_tween = create_tween()
	_toast_tween.set_parallel(true)
	_toast_tween.tween_property(_toast, "modulate:a", 1.0, 0.16)
	_toast_tween.tween_property(_toast, "scale", Vector2.ONE, 0.26).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_toast_tween.chain().tween_interval(hold)
	_toast_tween.chain().tween_property(_toast, "modulate:a", 0.0, 0.3)
	_toast_tween.chain().tween_callback(func() -> void: _toast.visible = false)


func set_countdown(text: String, hint: String = "GET READY") -> void:
	_countdown_label.text = text
	_countdown_label.visible = true
	_serve_hint.text = hint
	_serve_hint.visible = true
	if _countdown_tween and _countdown_tween.is_valid():
		_countdown_tween.kill()
	_countdown_label.modulate.a = 0.0
	_countdown_label.scale = Vector2(1.5, 1.5)
	_countdown_label.pivot_offset = Vector2(640, 80)
	_serve_hint.modulate.a = 0.0
	_countdown_tween = create_tween().set_parallel(true)
	_countdown_tween.tween_property(_countdown_label, "modulate:a", 1.0, 0.12)
	_countdown_tween.tween_property(_countdown_label, "scale", Vector2.ONE, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	_countdown_tween.tween_property(_serve_hint, "modulate:a", 1.0, 0.2)


func clear_countdown() -> void:
	if _countdown_tween and _countdown_tween.is_valid():
		_countdown_tween.kill()
	var tween := create_tween().set_parallel(true)
	tween.tween_property(_countdown_label, "modulate:a", 0.0, 0.14)
	tween.tween_property(_serve_hint, "modulate:a", 0.0, 0.14)
	tween.chain().tween_callback(func() -> void:
		_countdown_label.visible = false
		_serve_hint.visible = false
	)


func play_point_flash(player_scored: bool) -> void:
	var color := ArcadeTheme.TEAL if player_scored else ArcadeTheme.CORAL
	var flash := ColorRect.new()
	flash.color = Color(color.r, color.g, color.b, 0.16)
	flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(flash)
	var tween := create_tween()
	tween.tween_property(flash, "modulate:a", 0.0, 0.35)
	tween.tween_callback(flash.queue_free)


func reset_for_match() -> void:
	set_score(0, 0, false)
	set_round(1)
	set_round_wins(0, 0)
	set_match_status("FIRST TO 11")
	set_ball_speed(430.0, 980.0)
	_toast.visible = false
	_countdown_label.visible = false
	_serve_hint.visible = false
