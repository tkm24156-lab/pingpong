class_name MatchOverMenu
extends CanvasLayer
## End-of-match results card.

signal rematch_requested
signal menu_requested

var _root: Control
var _panel: PanelContainer
var _kicker: Label
var _title: Label
var _subtitle: Label
var _rounds: Label
var _stat_values: Array[Label] = []
var _fx: FXLayer
var _rematch_button: Button


func _ready() -> void:
	layer = 30
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _build() -> void:
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.theme = ArcadeTheme.make_theme()
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(_root)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.025, 0.08, 0.82)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	_root.add_child(dim)

	_fx = FXLayer.new()
	_fx.process_mode = Node.PROCESS_MODE_ALWAYS
	_root.add_child(_fx)
	_fx.z_index = 1

	_panel = PanelContainer.new()
	_panel.theme_type_variation = "ModalPanel"
	_panel.position = Vector2(320, 92)
	_panel.custom_minimum_size = Vector2(640, 536)
	_panel.z_index = 2
	_root.add_child(_panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 38)
	margin.add_theme_constant_override("margin_right", 38)
	margin.add_theme_constant_override("margin_top", 26)
	margin.add_theme_constant_override("margin_bottom", 28)
	_panel.add_child(margin)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	margin.add_child(column)

	_kicker = Label.new()
	_kicker.text = "MATCH COMPLETE"
	_kicker.theme_type_variation = "PillLabel"
	_kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_kicker.add_theme_color_override("font_color", ArcadeTheme.TEAL)
	column.add_child(_kicker)

	_title = Label.new()
	_title.text = "YOU WIN!"
	_title.theme_type_variation = "TitleLabel"
	_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_title.add_theme_font_size_override("font_size", 82)
	column.add_child(_title)

	_subtitle = Label.new()
	_subtitle.text = "THE CROWD GOES WILD"
	_subtitle.theme_type_variation = "DisplayLabel"
	_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_subtitle.add_theme_font_size_override("font_size", 19)
	_subtitle.add_theme_constant_override("outline_size", 4)
	_subtitle.add_theme_color_override("font_color", ArcadeTheme.MUTED)
	column.add_child(_subtitle)

	_rounds = Label.new()
	_rounds.text = "ROUNDS 2 — 0"
	_rounds.theme_type_variation = "DisplayLabel"
	_rounds.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_rounds.add_theme_font_size_override("font_size", 24)
	_rounds.add_theme_constant_override("outline_size", 4)
	_rounds.add_theme_color_override("font_color", ArcadeTheme.YELLOW)
	column.add_child(_rounds)

	var stats_row := HBoxContainer.new()
	stats_row.add_theme_constant_override("separation", 10)
	stats_row.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_child(stats_row)
	stats_row.add_child(_make_stat_card("LONGEST RALLY", "0"))
	stats_row.add_child(_make_stat_card("SMASHES", "0"))
	stats_row.add_child(_make_stat_card("BLOCKS", "0"))

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 4)
	column.add_child(spacer)

	_rematch_button = Button.new()
	_rematch_button.text = "REMATCH"
	_rematch_button.theme_type_variation = "PrimaryButton"
	_rematch_button.custom_minimum_size = Vector2(0, 62)
	_rematch_button.add_theme_font_size_override("font_size", 28)
	_rematch_button.pressed.connect(func() -> void: rematch_requested.emit())
	column.add_child(_rematch_button)

	var menu_button := Button.new()
	menu_button.text = "MAIN MENU"
	menu_button.theme_type_variation = "SecondaryButton"
	menu_button.custom_minimum_size = Vector2(0, 50)
	menu_button.add_theme_font_size_override("font_size", 22)
	menu_button.pressed.connect(func() -> void: menu_requested.emit())
	column.add_child(menu_button)


func _make_stat_card(label_text: String, value_text: String) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.theme_type_variation = "DarkPanel"
	panel.custom_minimum_size = Vector2(170, 84)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	panel.add_child(margin)
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 0)
	margin.add_child(column)
	var value := Label.new()
	value.text = value_text
	value.theme_type_variation = "ScoreLabel"
	value.add_theme_font_size_override("font_size", 36)
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(value)
	_stat_values.append(value)
	var caption := Label.new()
	caption.text = label_text
	caption.theme_type_variation = "MutedLabel"
	caption.add_theme_font_size_override("font_size", 10)
	caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	column.add_child(caption)
	return panel


func show_result(player_won: bool, player_rounds: int, ai_rounds: int, stats: Dictionary) -> void:
	visible = true
	_title.text = "YOU WIN!" if player_won else "DEFEAT"
	_title.add_theme_color_override("font_color", ArcadeTheme.YELLOW if player_won else ArcadeTheme.CORAL)
	_kicker.text = "VICTORY" if player_won else "MATCH COMPLETE"
	_subtitle.text = "THE CROWD GOES WILD" if player_won else "BOT-9000 TAKES THE CROWN"
	_rounds.text = "ROUNDS  %d — %d" % [player_rounds, ai_rounds]
	_stat_values[0].text = str(stats.get("longest_rally", 0))
	_stat_values[1].text = str(stats.get("smashes", 0))
	_stat_values[2].text = str(stats.get("blocks", 0))
	_root.modulate.a = 0.0
	_panel.scale = Vector2(0.82, 0.82)
	_panel.pivot_offset = Vector2(320, 268)
	var tween := create_tween().set_parallel(true)
	tween.tween_property(_root, "modulate:a", 1.0, 0.24)
	tween.tween_property(_panel, "scale", Vector2.ONE, 0.38).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	if player_won:
		_fx.confetti(Vector2(640, 140), 70, 980.0)
	_rematch_button.grab_focus()
