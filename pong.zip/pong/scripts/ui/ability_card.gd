class_name AbilityCard
extends PanelContainer
## Compact HUD card for an active ability.

var title_text := "SMASH"
var key_text := "SPACE"
var accent := ArcadeTheme.YELLOW
var _title_label: Label
var _status_label: Label
var _bar: ProgressBar
var _key_label: Label
var _panel_style: StyleBoxFlat
var _fill_normal: StyleBoxFlat
var _fill_active: StyleBoxFlat


func setup(p_title: String, p_key: String, p_accent: Color) -> void:
	title_text = p_title
	key_text = p_key
	accent = p_accent
	custom_minimum_size = Vector2(166, 54)
	_build()


func _build() -> void:
	_panel_style = ArcadeTheme.panel_style(Color(0.055, 0.063, 0.15, 0.9), Color(1, 1, 1, 0.12), 14, 2)
	_panel_style.shadow_size = 6
	add_theme_stylebox_override("panel", _panel_style)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 6)
	margin.add_theme_constant_override("margin_bottom", 6)
	add_child(margin)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 4)
	margin.add_child(column)

	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 6)
	column.add_child(header)

	var accent_chip := PanelContainer.new()
	var chip_style := ArcadeTheme._style(accent, Color(1, 1, 1, 0.2), 5, 0, 0)
	chip_style.content_margin_left = 5
	chip_style.content_margin_right = 5
	accent_chip.add_theme_stylebox_override("panel", chip_style)
	accent_chip.custom_minimum_size = Vector2(4, 12)
	accent_chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(accent_chip)

	_title_label = Label.new()
	_title_label.text = title_text
	_title_label.theme_type_variation = "DisplayLabel"
	_title_label.add_theme_font_size_override("font_size", 16)
	_title_label.add_theme_constant_override("outline_size", 3)
	_title_label.add_theme_color_override("font_color", ArcadeTheme.PAPER)
	_title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(_title_label)

	_key_label = Label.new()
	_key_label.text = key_text
	_key_label.theme_type_variation = "MutedLabel"
	_key_label.add_theme_font_size_override("font_size", 10)
	_key_label.add_theme_color_override("font_color", ArcadeTheme.INK)
	_key_label.add_theme_stylebox_override("normal", ArcadeTheme.keycap_style(accent))
	_key_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_key_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	header.add_child(_key_label)

	var bar_row := HBoxContainer.new()
	bar_row.add_theme_constant_override("separation", 6)
	column.add_child(bar_row)

	_bar = ProgressBar.new()
	_bar.theme_type_variation = "AbilityBar"
	_bar.show_percentage = false
	_bar.custom_minimum_size = Vector2(90, 7)
	_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_bar.max_value = 100.0
	_bar.value = 100.0
	_fill_normal = ArcadeTheme._style(accent, Color(0, 0, 0, 0), 5, 0, 0)
	_fill_active = ArcadeTheme._style(Color("#FFF8E9"), Color(0, 0, 0, 0), 5, 0, 0)
	_bar.add_theme_stylebox_override("fill", _fill_normal)
	bar_row.add_child(_bar)

	_status_label = Label.new()
	_status_label.theme_type_variation = "MutedLabel"
	_status_label.add_theme_font_size_override("font_size", 10)
	_status_label.add_theme_color_override("font_color", accent)
	_status_label.custom_minimum_size = Vector2(44, 0)
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_status_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_status_label.text = "READY"
	bar_row.add_child(_status_label)
	set_state(true, false, 0.0, 1.0)


func set_state(ready: bool, active: bool, cooldown_left: float, cooldown_total: float) -> void:
	if not _bar:
		return
	var ratio := 1.0
	if cooldown_left > 0.0:
		ratio = clampf(1.0 - cooldown_left / maxf(cooldown_total, 0.001), 0.0, 1.0)
	_bar.value = ratio * 100.0
	var border_color := Color(1, 1, 1, 0.12)
	if active:
		_status_label.text = "ACTIVE"
		_status_label.add_theme_color_override("font_color", Color("#FFF8E9"))
		_bar.add_theme_stylebox_override("fill", _fill_active)
		border_color = accent
	elif ready:
		_status_label.text = "READY"
		_status_label.add_theme_color_override("font_color", accent)
		_bar.add_theme_stylebox_override("fill", _fill_normal)
		border_color = Color(accent.r, accent.g, accent.b, 0.45)
	else:
		_status_label.text = "%.1fs" % cooldown_left
		_status_label.add_theme_color_override("font_color", ArcadeTheme.MUTED)
		_bar.add_theme_stylebox_override("fill", _fill_normal)
	_panel_style.border_color = border_color
	if active:
		_panel_style.bg_color = Color(accent.r * 0.18, accent.g * 0.18, accent.b * 0.18, 0.94)
	else:
		_panel_style.bg_color = Color(0.055, 0.063, 0.15, 0.9)
