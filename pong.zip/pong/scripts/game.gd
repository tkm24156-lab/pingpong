extends Node2D
## Match controller for Pong Panic.

enum State { BOOT, READY, SERVE, PLAYING, POINT, ROUND_OVER, MATCH_OVER }

const BALL_RADIUS := 13.0
const COURT_TOP := 112.0
const COURT_BOTTOM := 648.0
const COURT_LEFT := 70.0
const COURT_RIGHT := 1210.0
const COURT_CENTER := Vector2(640, 380)
const PLAYER_PADDLE_X := 170.0
const AI_PADDLE_X := 1110.0
const PLAYER_SPEED := 690.0
const BASE_BALL_SPEED := 440.0
const MAX_BALL_SPEED := 980.0
const SMASH_COOLDOWN := 5.0
const SMASH_WINDOW := 0.38
const GUARD_COOLDOWN := 6.0
const GUARD_WINDOW := 1.35
const AI_SMASH_COOLDOWN := 4.5
const AI_GUARD_COOLDOWN := 5.0

var _arena: Node2D
var _maya: CharacterView
var _bot: CharacterView
var _player_paddle: Paddle
var _ai_paddle: Paddle
var _ball: PongBall
var _fx: FXLayer
var _ai: AIController
var _hud: GameHUD
var _pause_menu: PauseMenu
var _match_over_menu: MatchOverMenu

var _state := State.BOOT
var _player_score := 0
var _ai_score := 0
var _player_rounds := 0
var _ai_rounds := 0
var _round_number := 1
var _rally_hits := 0
var _longest_rally := 0
var _smashes := 0
var _blocks := 0
var _smash: CooldownAbility
var _guard: CooldownAbility
var _ai_guard_active := false
var _ai_guard_armed := false
var _ai_guard_time := 0.0
var _ai_guard_cooldown := 0.0
var _ai_smash_cooldown := 0.0
var _ai_smash_visual := 0.0
var _sequence_id := 0
var _serve_direction := 1
var _shake_strength := 0.0
var _hud_tick := 0.0
var _ability_error_cooldown := 0.0
var _rng := RandomNumberGenerator.new()
var _player_paddle_bounds := Vector2(185.0, 575.0)
var _restarting := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rng.randomize()
	_arena = $Arena
	_arena.process_mode = Node.PROCESS_MODE_PAUSABLE
	_smash = CooldownAbility.new(SMASH_COOLDOWN, SMASH_WINDOW)
	_guard = CooldownAbility.new(GUARD_COOLDOWN, GUARD_WINDOW)
	_build_world()
	_build_ui()
	_refresh_ai_profile()
	Sfx.play_music("gameplay")
	get_tree().paused = false
	_start_new_match()


func _build_world() -> void:
	_maya = CharacterView.new()
	_maya.name = "Maya"
	_maya.character = "maya"
	_maya.facing = 1
	_maya.visual_scale = 0.82
	_maya.position = Vector2(76, 568)
	_maya.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(_maya)

	_bot = CharacterView.new()
	_bot.name = "Bot"
	_bot.character = "bot"
	_bot.facing = -1
	_bot.visual_scale = 0.82
	_bot.position = Vector2(1204, 568)
	_bot.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(_bot)

	_player_paddle = Paddle.new()
	_player_paddle.name = "PlayerPaddle"
	_player_paddle.side = 0
	_player_paddle.is_player = true
	_player_paddle.accent = ArcadeTheme.TEAL
	_player_paddle.position = Vector2(PLAYER_PADDLE_X, COURT_CENTER.y)
	_player_paddle.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(_player_paddle)

	_ai_paddle = Paddle.new()
	_ai_paddle.name = "AIPaddle"
	_ai_paddle.side = 1
	_ai_paddle.is_player = false
	_ai_paddle.accent = ArcadeTheme.CORAL
	_ai_paddle.position = Vector2(AI_PADDLE_X, COURT_CENTER.y)
	_ai_paddle.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(_ai_paddle)

	_ball = PongBall.new()
	_ball.name = "Ball"
	_ball.position = COURT_CENTER
	_ball.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(_ball)

	_fx = FXLayer.new()
	_fx.name = "FX"
	_fx.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(_fx)

	_ai = AIController.new()
	_ai.name = "AIController"
	_ai.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(_ai)


func _build_ui() -> void:
	_hud = GameHUD.new()
	_hud.name = "HUD"
	add_child(_hud)
	_hud.pause_pressed.connect(_pause_match)
	_hud.setup_names(GameState.PLAYER_NAME, GameState.AI_NAME)
	_hud.set_round_wins(0, 0)

	_pause_menu = PauseMenu.new()
	_pause_menu.name = "PauseMenu"
	add_child(_pause_menu)
	_pause_menu.resume_requested.connect(_resume_match)
	_pause_menu.restart_requested.connect(_restart_from_pause)
	_pause_menu.menu_requested.connect(_return_to_menu)
	_pause_menu.sound_toggled.connect(_toggle_sound)

	_match_over_menu = MatchOverMenu.new()
	_match_over_menu.name = "MatchOverMenu"
	add_child(_match_over_menu)
	_match_over_menu.rematch_requested.connect(_rematch)
	_match_over_menu.menu_requested.connect(_return_to_menu)


func _refresh_ai_profile() -> void:
	_ai.setup(GameState.get_ai_profile(), COURT_CENTER.y)
	_hud.setup_names(GameState.PLAYER_NAME, GameState.AI_NAME)


func _start_new_match() -> void:
	_sequence_id += 1
	_restarting = false
	get_tree().paused = false
	_pause_menu.close()
	_match_over_menu.visible = false
	position = Vector2.ZERO
	_shake_strength = 0.0
	_player_rounds = 0
	_ai_rounds = 0
	_round_number = 1
	_smashes = 0
	_blocks = 0
	_longest_rally = 0
	_hud.reset_for_match()
	_hud.set_round_wins(0, 0)
	_refresh_ai_profile()
	_start_round_sequence()


func _start_round_sequence() -> void:
	_sequence_id += 1
	var token := _sequence_id
	_state = State.READY
	_player_score = 0
	_ai_score = 0
	_rally_hits = 0
	_smash.reset()
	_guard.reset()
	_ai_guard_active = false
	_ai_guard_armed = false
	_ai_guard_time = 0.0
	_ai_guard_cooldown = 0.0
	_ai_smash_cooldown = 0.0
	_ai_smash_visual = 0.0
	_ball.visible = true
	_ball.reset_to(COURT_CENTER)
	_ball.set_active(false)
	_player_paddle.position = Vector2(PLAYER_PADDLE_X, COURT_CENTER.y)
	_player_paddle.velocity_y = 0.0
	_player_paddle.smash_active = false
	_player_paddle.guard_active = false
	_ai_paddle.position = Vector2(AI_PADDLE_X, COURT_CENTER.y)
	_ai_paddle.velocity_y = 0.0
	_ai_paddle.smash_active = false
	_ai_paddle.guard_active = false
	_maya.react("idle")
	_bot.react("idle")
	_hud.set_score(0, 0, false)
	_hud.set_round(_round_number)
	_hud.set_round_wins(_player_rounds, _ai_rounds)
	_hud.set_ball_speed(BASE_BALL_SPEED, MAX_BALL_SPEED)
	_hud.set_match_status("FIRST TO 11 • WIN BY 2")
	_hud.update_abilities(true, false, 0.0, SMASH_COOLDOWN, true, false, 0.0, GUARD_COOLDOWN)
	_hud.announce("ROUND %d" % _round_number, "FIRST TO 11 • WIN BY 2", ArcadeTheme.YELLOW, 0.75)
	Sfx.play_sfx("confirm", -10.0, 1.0)
	await _wait(1.25)
	if token != _sequence_id:
		return
	_serve_direction = 1 if _rng.randi_range(0, 1) == 0 else -1
	await _serve_sequence(token, _serve_direction)


func _serve_sequence(token: int, direction: int) -> void:
	if token != _sequence_id:
		return
	_state = State.SERVE
	_ball.reset_to(COURT_CENTER)
	_ball.visible = true
	_ball.set_active(false)
	_player_paddle.position.y = COURT_CENTER.y
	_ai_paddle.position.y = COURT_CENTER.y
	var hint := "YOUR SERVE" if direction > 0.0 else "BOT SERVES"
	_hud.set_countdown("3", hint)
	Sfx.play_sfx("switch", -16.0, 0.72)
	await _wait(0.38)
	if token != _sequence_id:
		return
	_hud.set_countdown("2", hint)
	Sfx.play_sfx("switch", -16.0, 0.82)
	await _wait(0.38)
	if token != _sequence_id:
		return
	_hud.set_countdown("1", hint)
	Sfx.play_sfx("switch", -16.0, 0.92)
	await _wait(0.38)
	if token != _sequence_id:
		return
	_hud.set_countdown("GO!", "RALLY!")
	Sfx.play_sfx("confirm", -10.0, 1.25)
	_launch_ball(direction)
	await _wait(0.26)
	if token != _sequence_id:
		return
	_hud.clear_countdown()


func _launch_ball(direction: int) -> void:
	_ball.position = COURT_CENTER
	_ball.visible = true
	_ball.set_active(true)
	var angle := _rng.randf_range(-0.20, 0.20)
	_ball.velocity = Vector2(cos(angle) * direction, sin(angle)) * BASE_BALL_SPEED
	_ball.set_velocity(_ball.velocity)
	_ball.glow(ArcadeTheme.YELLOW, 0.4)
	_ball.add_trail_point()
	_rally_hits = 0
	_state = State.PLAYING
	_hud.set_ball_speed(BASE_BALL_SPEED, MAX_BALL_SPEED)
	_hud.set_match_status("RALLY!")


func _physics_process(delta: float) -> void:
	if get_tree().paused:
		return
	if _state == State.SERVE or _state == State.PLAYING or _state == State.READY:
		_move_player_paddle(delta)
	if _state == State.SERVE or _state == State.READY:
		_ai_paddle.move_to_target(COURT_CENTER.y, _ai.profile.get("move_speed", 400.0) * 0.7, delta, _player_paddle_bounds)
	elif _state == State.PLAYING:
		var target := _ai.update_ai(delta, _ball, _ai_paddle, _player_paddle_bounds)
		_ai_paddle.move_to_target(target, float(_ai.profile.get("move_speed", 440.0)), delta, _player_paddle_bounds)
		_update_ai_guard_activation(delta)
		_move_ball(delta)


func _process(delta: float) -> void:
	if get_tree().paused:
		return
	_smash.tick(delta)
	_guard.tick(delta)
	_ability_error_cooldown = maxf(0.0, _ability_error_cooldown - delta)
	_ai_guard_cooldown = maxf(0.0, _ai_guard_cooldown - delta)
	_ai_smash_cooldown = maxf(0.0, _ai_smash_cooldown - delta)
	_ai_smash_visual = maxf(0.0, _ai_smash_visual - delta)
	_update_shake(delta)
	_handle_ability_input()
	if _guard.is_active() and Input.is_action_just_released("guard"):
		_guard.end_active()

	_player_paddle.smash_active = _smash.is_active()
	_player_paddle.guard_active = _guard.is_active()
	_ai_paddle.smash_active = _ai_smash_visual > 0.0
	if not _ai_guard_active:
		_ai_paddle.guard_active = false

	_hud_tick += delta
	if _hud_tick >= 0.05:
		_hud_tick = 0.0
		_hud.update_abilities(
			_smash.is_ready(), _smash.is_active(), _smash.cooldown_left, SMASH_COOLDOWN,
			_guard.is_ready(), _guard.is_active(), _guard.cooldown_left, GUARD_COOLDOWN
		)
		_hud.set_ball_speed(_ball.velocity.length() if _ball.is_active else BASE_BALL_SPEED, MAX_BALL_SPEED)


func _move_player_paddle(delta: float) -> void:
	if get_tree().paused:
		return
	var axis := Input.get_axis("move_up", "move_down")
	var target := _player_paddle.position.y + axis * 40.0
	_player_paddle.move_to_target(target, PLAYER_SPEED, delta, _player_paddle_bounds)


func _handle_ability_input() -> void:
	if _state != State.PLAYING:
		return
	if Input.is_action_just_pressed("smash"):
		if _guard.is_active():
			_ability_error()
			return
		if _smash.trigger():
			Sfx.play_sfx("switch", -7.0, 1.32)
			_player_paddle.hit_reaction(false, true)
			_fx.ring(_player_paddle.position, ArcadeTheme.YELLOW, 14.0, 90.0, 4.0)
		else:
			_ability_error()
	if Input.is_action_just_pressed("guard"):
		if _smash.is_active():
			_ability_error()
			return
		if _guard.trigger():
			Sfx.play_sfx("guard", -8.0, 1.12)
			_fx.ring(_player_paddle.position, ArcadeTheme.TEAL, 18.0, 100.0, 4.0)
		else:
			_ability_error()


func _ability_error() -> void:
	if _ability_error_cooldown > 0.0:
		return
	_ability_error_cooldown = 0.28
	Sfx.play_sfx("error", -18.0, 1.25)


func _move_ball(delta: float) -> void:
	if not _ball.is_active:
		return
	var travel := _ball.velocity * delta
	var distance := travel.length()
	var steps := maxi(1, ceili(distance / 6.0))
	var step := travel / float(steps)
	for i in steps:
		_ball.position += step
		if _resolve_wall_collision():
			pass
		if _resolve_paddle_collision():
			break
		if _resolve_goal():
			return
	_ball.add_trail_point()


func _resolve_wall_collision() -> bool:
	var bounced := false
	var top := COURT_TOP + BALL_RADIUS + 1.0
	var bottom := COURT_BOTTOM - BALL_RADIUS - 1.0
	if _ball.position.y < top and _ball.velocity.y < 0.0:
		_ball.position.y = top
		_ball.velocity.y = absf(_ball.velocity.y)
		bounced = true
	elif _ball.position.y > bottom and _ball.velocity.y > 0.0:
		_ball.position.y = bottom
		_ball.velocity.y = -absf(_ball.velocity.y)
		bounced = true
	if bounced:
		_ball.set_velocity(_ball.velocity)
		Sfx.play_sfx("wall_hit", -18.0, _rng.randf_range(0.95, 1.1))
		_fx.burst(Vector2(_ball.position.x, top if _ball.position.y <= top + 1.0 else bottom), ArcadeTheme.BLUE, 5, 150.0, Vector2(0, 1 if _ball.position.y <= top + 1.0 else -1))
		_add_shake(2.0)
	return bounced


func _resolve_paddle_collision() -> bool:
	if _ball.velocity.x < 0.0:
		var left_rect := _player_paddle.get_collision_rect().grow(BALL_RADIUS)
		if left_rect.has_point(_ball.position):
			_ball.position.x = _player_paddle.position.x + _player_paddle.get_half_width() + BALL_RADIUS + 1.0
			_handle_paddle_hit(true)
			return true
	elif _ball.velocity.x > 0.0:
		var right_rect := _ai_paddle.get_collision_rect().grow(BALL_RADIUS)
		if right_rect.has_point(_ball.position):
			_ball.position.x = _ai_paddle.position.x - _ai_paddle.get_half_width() - BALL_RADIUS - 1.0
			_handle_paddle_hit(false)
			return true
	return false


func _handle_paddle_hit(is_player: bool) -> void:
	_rally_hits += 1
	_longest_rally = maxi(_longest_rally, _rally_hits)
	var incoming_speed := _ball.velocity.length()
	var outgoing_speed := clampf(incoming_speed + 13.0 + minf(_rally_hits, 10) * 2.2, BASE_BALL_SPEED, MAX_BALL_SPEED)
	var used_smash := false
	var used_guard := false
	var hit_paddle := _player_paddle if is_player else _ai_paddle

	if is_player:
		if _smash.is_active():
			used_smash = true
			_smash.end_active()
			_smashes += 1
			outgoing_speed = minf(MAX_BALL_SPEED, outgoing_speed + 165.0)
		if _guard.is_active():
			used_guard = true
			_guard.end_active()
			_blocks += 1
			outgoing_speed = clampf(outgoing_speed * 0.68, BASE_BALL_SPEED * 0.86, MAX_BALL_SPEED)
	else:
		if _ai_guard_active:
			used_guard = true
			_ai_guard_active = false
			_ai_guard_time = 0.0
			outgoing_speed = clampf(outgoing_speed * 0.72, BASE_BALL_SPEED * 0.88, MAX_BALL_SPEED)
		elif _ai_smash_cooldown <= 0.0 and _ai.should_smash():
			used_smash = true
			_ai_smash_cooldown = AI_SMASH_COOLDOWN
			_ai_smash_visual = 0.35
			outgoing_speed = minf(MAX_BALL_SPEED, outgoing_speed + 150.0)

	var contact := clampf((_ball.position.y - hit_paddle.position.y) / (_player_paddle.get_half_height() + BALL_RADIUS), -1.0, 1.0)
	var max_angle := deg_to_rad(53.0)
	var angle := contact * max_angle
	# A guard block sends the ball back on a calmer line.
	if used_guard:
		angle *= 0.55
	var direction := 1.0 if is_player else -1.0
	_ball.velocity = Vector2(cos(angle) * direction, sin(angle)) * outgoing_speed
	_ball.set_velocity(_ball.velocity)
	_hud.set_ball_speed(outgoing_speed, MAX_BALL_SPEED)

	hit_paddle.hit_reaction(used_guard, used_smash)
	var impact_pos := Vector2(hit_paddle.position.x + (BALL_RADIUS + 16.0) * direction, _ball.position.y)
	var impact_color := ArcadeTheme.YELLOW if used_smash else ArcadeTheme.TEAL if is_player else ArcadeTheme.CORAL
	_fx.burst(impact_pos, impact_color, 16 if used_smash else 9, 470.0 if used_smash else 260.0, Vector2(direction, 0))
	_fx.ring(impact_pos, impact_color, 12.0, 120.0 if used_smash else 65.0, 5.0 if used_smash else 3.0)
	_ball.glow(ArcadeTheme.CORAL if used_smash else ArcadeTheme.YELLOW, 0.7 if used_smash else 0.2)
	_add_shake(7.0 if used_smash else 2.5)

	if used_smash:
		Sfx.play_sfx("smash", -3.0, 0.92 if is_player else 0.82)
		_fx.flash(impact_color, 0.10, 5.0)
	elif used_guard:
		Sfx.play_sfx("guard", -5.0, 0.92)
		_fx.flash(ArcadeTheme.TEAL, 0.06, 5.0)
	else:
		Sfx.play_sfx("paddle_hit", -6.0, 1.16 if is_player else 0.88)

	if is_player:
		_maya.react("smash" if used_smash else "hit")
		_bot.react("hurt" if used_smash else "idle")
	else:
		_bot.react("smash" if used_smash else "hit")
		_maya.react("hurt" if used_smash else "idle")
		# The bot may arm a guard for the next return.
		if not used_guard and not used_smash and _ai_guard_cooldown <= 0.0 and _ai.should_guard():
			_ai_guard_armed = true


func _update_ai_guard_activation(delta: float) -> void:
	if _ai_guard_active:
		_ai_guard_time -= delta
		if _ai_guard_time <= 0.0:
			_ai_guard_active = false
		_ai_paddle.guard_active = _ai_guard_active
		return
	if _ai_guard_armed and _ai_guard_cooldown <= 0.0 and _ball.is_active and _ball.velocity.x > 0.0 and _ball.position.x > 820.0:
		_ai_guard_active = true
		_ai_guard_time = 0.85
		_ai_guard_armed = false
		_ai_guard_cooldown = AI_GUARD_COOLDOWN
		_ai_paddle.guard_active = true
		_fx.ring(_ai_paddle.position, ArcadeTheme.CORAL, 18.0, 95.0, 3.0)
		Sfx.play_sfx("guard", -14.0, 0.82)
	else:
		_ai_paddle.guard_active = false


func _resolve_goal() -> bool:
	if _ball.position.x - BALL_RADIUS <= COURT_LEFT:
		_score_point(false)
		return true
	if _ball.position.x + BALL_RADIUS >= COURT_RIGHT:
		_score_point(true)
		return true
	return false


func _score_point(player_scored: bool) -> void:
	if _state != State.PLAYING:
		return
	_state = State.POINT
	_sequence_id += 1
	var token := _sequence_id
	_smash.end_active()
	_guard.end_active()
	_ball.set_active(false)
	_ball.visible = false
	var scorer_color := ArcadeTheme.TEAL if player_scored else ArcadeTheme.CORAL
	var goal_pos := Vector2(COURT_LEFT + 18.0 if player_scored else COURT_RIGHT - 18.0, _ball.position.y)
	_fx.burst(goal_pos, scorer_color, 28, 520.0, Vector2.RIGHT if player_scored else Vector2.LEFT)
	_fx.ring(goal_pos, scorer_color, 18.0, 160.0, 5.0)
	_fx.flash(scorer_color, 0.16, 5.0)
	_add_shake(10.0)
	Sfx.play_sfx("point", -3.0, 1.05 if player_scored else 0.9)
	_hud.play_point_flash(player_scored)

	if player_scored:
		_player_score += 1
		_maya.react("cheer")
		_bot.react("sad")
	else:
		_ai_score += 1
		_bot.react("cheer")
		_maya.react("sad")
	_hud.set_score(_player_score, _ai_score)
	_refresh_match_status()

	var round_over := MatchRules.round_is_won(_player_score, _ai_score)
	if round_over:
		await _wait(0.55)
		if token != _sequence_id:
			return
		_finish_round(player_scored, token)
		return

	var point_status := MatchRules.point_status(_player_score, _ai_score)
	var main_text := "POINT!"
	var sub_text := "%s  %d — %d  %s" % [GameState.PLAYER_NAME, _player_score, _ai_score, GameState.AI_NAME]
	var color := scorer_color
	if MatchRules.match_point_for(_player_rounds, _ai_rounds, _player_score, _ai_score):
		main_text = "MATCH POINT!"
		color = ArcadeTheme.YELLOW
	elif MatchRules.match_point_against(_player_rounds, _ai_rounds, _player_score, _ai_score):
		main_text = "MATCH POINT!"
		color = ArcadeTheme.CORAL
	elif point_status == "deuce":
		main_text = "DEUCE!"
		sub_text = "WIN BY TWO TO TAKE THE ROUND"
		color = ArcadeTheme.YELLOW
	elif point_status == "advantage_player":
		main_text = "ADVANTAGE MAYA"
		color = ArcadeTheme.TEAL
	elif point_status == "advantage_ai":
		main_text = "ADVANTAGE BOT"
		color = ArcadeTheme.CORAL
	elif point_status == "game":
		main_text = "GAME POINT!"
		color = ArcadeTheme.YELLOW
	_hud.announce(main_text, sub_text, color, 0.55)
	await _wait(1.15)
	if token != _sequence_id:
		return
	_serve_direction = 1 if player_scored else -1
	await _serve_sequence(token, _serve_direction)


func _finish_round(player_won_round: bool, token: int) -> void:
	if token != _sequence_id:
		return
	_state = State.ROUND_OVER
	_ball.set_active(false)
	_ball.visible = false
	if player_won_round:
		_player_rounds += 1
	else:
		_ai_rounds += 1
	_hud.set_round_wins(_player_rounds, _ai_rounds)
	_hud.set_match_status("ROUND %d COMPLETE" % _round_number, ArcadeTheme.YELLOW)
	var round_color := ArcadeTheme.YELLOW if player_won_round else ArcadeTheme.CORAL
	var round_title := "ROUND TO MAYA!" if player_won_round else "ROUND TO BOT!"
	_hud.announce(round_title, "ROUNDS  %d — %d" % [_player_rounds, _ai_rounds], round_color, 1.2)
	_fx.confetti(Vector2(640, 120), 45, 960.0)
	_fx.flash(round_color, 0.14, 4.0)
	Sfx.play_sfx("confirm", -4.0, 1.0)
	await _wait(2.25)
	if token != _sequence_id:
		return
	if MatchRules.match_is_won(_player_rounds, _ai_rounds):
		_finish_match(_player_rounds > _ai_rounds)
		return
	_round_number += 1
	_start_round_sequence()


func _finish_match(player_won_match: bool) -> void:
	_sequence_id += 1
	var token := _sequence_id
	_state = State.MATCH_OVER
	_ball.set_active(false)
	_ball.visible = false
	_smash.end_active()
	_guard.end_active()
	_hud.clear_countdown()
	_hud.set_score(_player_score, _ai_score)
	_hud.announce("MATCH POINT!" if player_won_match else "BOT WINS", "", ArcadeTheme.YELLOW if player_won_match else ArcadeTheme.CORAL, 0.8)
	Sfx.play_stinger(player_won_match)
	await _wait(0.9)
	if token != _sequence_id:
		return
	_match_over_menu.show_result(player_won_match, _player_rounds, _ai_rounds, {
		"longest_rally": _longest_rally,
		"smashes": _smashes,
		"blocks": _blocks,
	})


func _refresh_match_status() -> void:
	var status := MatchRules.point_status(_player_score, _ai_score)
	var text := "FIRST TO 11 • WIN BY 2"
	var color := ArcadeTheme.MUTED
	if MatchRules.match_point_for(_player_rounds, _ai_rounds, _player_score, _ai_score):
		text = "MATCH POINT • MAYA"
		color = ArcadeTheme.YELLOW
	elif MatchRules.match_point_against(_player_rounds, _ai_rounds, _player_score, _ai_score):
		text = "MATCH POINT • BOT"
		color = ArcadeTheme.CORAL
	else:
		match status:
			"deuce":
				text = "DEUCE • WIN BY 2"
				color = ArcadeTheme.YELLOW
			"advantage_player":
				text = "ADVANTAGE MAYA"
				color = ArcadeTheme.TEAL
			"advantage_ai":
				text = "ADVANTAGE BOT"
				color = ArcadeTheme.CORAL
			"game":
				text = "GAME POINT"
				color = ArcadeTheme.YELLOW
	_hud.set_match_status(text, color)


func _add_shake(amount: float) -> void:
	_shake_strength = maxf(_shake_strength, amount)


func _update_shake(delta: float) -> void:
	if _shake_strength > 0.0:
		_shake_strength = maxf(0.0, _shake_strength - delta * 30.0)
		position = Vector2(_rng.randf_range(-1.0, 1.0), _rng.randf_range(-1.0, 1.0)) * _shake_strength
	else:
		position = Vector2.ZERO


func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds, false).timeout


func _input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_game"):
		if _state == State.MATCH_OVER:
			return
		if get_tree().paused:
			_resume_match()
		else:
			_pause_match()
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("mute"):
		_toggle_sound()
		get_viewport().set_input_as_handled()


func _pause_match() -> void:
	if get_tree().paused or _state == State.MATCH_OVER or _state == State.BOOT:
		return
	get_tree().paused = true
	_shake_strength = 0.0
	position = Vector2.ZERO
	_pause_menu.open()
	Sfx.pause_music(true)
	Sfx.play_sfx("click", -4.0, 0.95)


func _resume_match() -> void:
	if not get_tree().paused:
		return
	get_tree().paused = false
	_pause_menu.close()
	Sfx.pause_music(false)
	Sfx.play_sfx("back", -8.0, 1.05)


func _restart_from_pause() -> void:
	get_tree().paused = false
	_pause_menu.close()
	Sfx.pause_music(false)
	Sfx.play_sfx("confirm", -3.0, 1.0)
	_start_new_match()


func _rematch() -> void:
	if _restarting:
		return
	_restarting = true
	Sfx.play_sfx("confirm", -3.0, 1.0)
	get_tree().paused = false
	_match_over_menu.visible = false
	_start_new_match()


func _return_to_menu() -> void:
	get_tree().paused = false
	Sfx.pause_music(false)
	Sfx.play_sfx("back", -4.0, 1.0)
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _toggle_sound() -> void:
	GameState.toggle_sound()
	Sfx.apply_sound_setting()
	Sfx.play_sfx("click", -4.0, 1.0)


func get_debug_state() -> Dictionary:
	return {
		"state": _state,
		"player_score": _player_score,
		"ai_score": _ai_score,
		"player_rounds": _player_rounds,
		"ai_rounds": _ai_rounds,
		"round": _round_number,
		"rally_hits": _rally_hits,
		"longest_rally": _longest_rally,
		"smashes": _smashes,
		"blocks": _blocks,
		"ball_speed": _ball.velocity.length() if _ball else 0.0,
		"ball_active": _ball.is_active if _ball else false,
		"player_y": _player_paddle.position.y if _player_paddle else 0.0,
		"ai_y": _ai_paddle.position.y if _ai_paddle else 0.0,
	}
