class_name FXLayer
extends Node2D
## Lightweight custom-drawn particles for impacts, trails, and celebrations.

class Spark:
	var pos: Vector2
	var vel: Vector2
	var life: float
	var max_life: float
	var size: float
	var color: Color
	var gravity: float


class Ring:
	var pos: Vector2
	var radius: float
	var speed: float
	var life: float
	var max_life: float
	var color: Color
	var width: float


class Confetti:
	var pos: Vector2
	var vel: Vector2
	var rotation: float
	var spin: float
	var size: Vector2
	var color: Color
	var life: float
	var max_life: float


var _sparks: Array[Spark] = []
var _rings: Array[Ring] = []
var _confetti: Array[Confetti] = []
var _flash_color := Color(1, 1, 1, 0)
var _flash_alpha := 0.0
var _flash_decay := 3.0
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	z_index = 20
	_rng.randomize()


func burst(at: Vector2, color: Color, count: int = 14, power: float = 320.0, direction: Vector2 = Vector2.ZERO) -> void:
	for i in count:
		var spark := Spark.new()
		spark.pos = at
		var angle: float
		if direction == Vector2.ZERO:
			angle = _rng.randf_range(0.0, TAU)
		else:
			angle = direction.angle() + _rng.randf_range(-1.2, 1.2)
		var speed := _rng.randf_range(power * 0.35, power)
		spark.vel = Vector2(cos(angle), sin(angle)) * speed
		spark.max_life = _rng.randf_range(0.24, 0.55)
		spark.life = spark.max_life
		spark.size = _rng.randf_range(2.0, 5.5)
		spark.color = color.lerp(Color("#FFF8E9"), _rng.randf_range(0.0, 0.6))
		spark.gravity = 420.0
		_sparks.append(spark)
	ring(at, color, 12.0, 55.0)


func ring(at: Vector2, color: Color, start_radius: float = 16.0, growth: float = 110.0, width: float = 4.0) -> void:
	var shock := Ring.new()
	shock.pos = at
	shock.radius = start_radius
	shock.speed = growth
	shock.max_life = 0.34
	shock.life = shock.max_life
	shock.color = color
	shock.width = width
	_rings.append(shock)


func confetti(at: Vector2, count: int = 46, spread: float = 640.0) -> void:
	var palette := [ArcadeTheme.YELLOW, ArcadeTheme.CORAL, ArcadeTheme.TEAL, ArcadeTheme.BLUE, ArcadeTheme.PINK, ArcadeTheme.PURPLE]
	for i in count:
		var piece := Confetti.new()
		piece.pos = at + Vector2(_rng.randf_range(-spread * 0.45, spread * 0.45), _rng.randf_range(-40, 30))
		piece.vel = Vector2(_rng.randf_range(-spread * 0.35, spread * 0.35), _rng.randf_range(-520.0, -180.0))
		piece.rotation = _rng.randf_range(0.0, TAU)
		piece.spin = _rng.randf_range(-10.0, 10.0)
		piece.size = Vector2(_rng.randf_range(5.0, 12.0), _rng.randf_range(3.0, 7.0))
		piece.color = palette[_rng.randi() % palette.size()]
		piece.max_life = _rng.randf_range(1.0, 2.2)
		piece.life = piece.max_life
		_confetti.append(piece)


func flash(color: Color = Color(1, 1, 1, 1), alpha: float = 0.22, decay: float = 5.0) -> void:
	_flash_color = color
	_flash_alpha = maxf(_flash_alpha, alpha)
	_flash_decay = decay


func _process(delta: float) -> void:
	var active := false
	for i in range(_sparks.size() - 1, -1, -1):
		var spark := _sparks[i]
		spark.life -= delta
		if spark.life <= 0.0:
			_sparks.remove_at(i)
			continue
		spark.vel.y += spark.gravity * delta
		spark.vel *= 1.0 - delta * 1.8
		spark.pos += spark.vel * delta
		active = true
	for i in range(_rings.size() - 1, -1, -1):
		var shock := _rings[i]
		shock.life -= delta
		if shock.life <= 0.0:
			_rings.remove_at(i)
			continue
		shock.radius += shock.speed * delta
		active = true
	for i in range(_confetti.size() - 1, -1, -1):
		var piece := _confetti[i]
		piece.life -= delta
		if piece.life <= 0.0:
			_confetti.remove_at(i)
			continue
		piece.vel.y += 390.0 * delta
		piece.vel.x *= 1.0 - delta * 0.3
		piece.pos += piece.vel * delta
		piece.rotation += piece.spin * delta
		active = true
	if _flash_alpha > 0.0:
		_flash_alpha = maxf(0.0, _flash_alpha - _flash_decay * delta)
		active = true
	if active:
		queue_redraw()


func _draw() -> void:
	for shock in _rings:
		var alpha := clampf(shock.life / shock.max_life, 0.0, 1.0)
		draw_arc(shock.pos, shock.radius, 0.0, TAU, 40, Color(shock.color.r, shock.color.g, shock.color.b, alpha * 0.8), shock.width, true)
	for spark in _sparks:
		var alpha := clampf(spark.life / spark.max_life, 0.0, 1.0)
		var tail := spark.pos - spark.vel * 0.018
		draw_line(tail, spark.pos, Color(spark.color.r, spark.color.g, spark.color.b, alpha), spark.size, true)
		draw_circle(spark.pos, spark.size * 0.42, Color(1, 1, 1, alpha * 0.8))
	for piece in _confetti:
		var alpha := clampf(piece.life / piece.max_life, 0.0, 1.0)
		var x_axis := Vector2(cos(piece.rotation), sin(piece.rotation)) * piece.size.x * 0.5
		var y_axis := Vector2(-sin(piece.rotation), cos(piece.rotation)) * piece.size.y * 0.5
		var points := PackedVector2Array([
			piece.pos - x_axis - y_axis,
			piece.pos + x_axis - y_axis,
			piece.pos + x_axis + y_axis,
			piece.pos - x_axis + y_axis,
		])
		draw_colored_polygon(points, Color(piece.color.r, piece.color.g, piece.color.b, alpha))
	if _flash_alpha > 0.0:
		draw_rect(Rect2(-20, -20, 1320, 760), Color(_flash_color.r, _flash_color.g, _flash_color.b, _flash_alpha))
