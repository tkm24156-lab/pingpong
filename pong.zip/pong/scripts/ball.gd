class_name PongBall
extends Node2D
## Visual ball. Movement and collision live in the match controller.

const RADIUS := 13.0
const TRAIL_LENGTH := 16

var radius := RADIUS
var velocity := Vector2.ZERO
var is_active := false
var accent := Color("#FFD447")
var base_accent := Color("#FFD447")
var _trail: Line2D
var _time := 0.0
var _pop_tween: Tween


func _ready() -> void:
	z_index = 8
	_trail = Line2D.new()
	_trail.name = "Trail"
	_trail.width = 13.0
	_trail.joint_mode = Line2D.LINE_JOINT_ROUND
	_trail.begin_cap_mode = Line2D.LINE_CAP_ROUND
	_trail.end_cap_mode = Line2D.LINE_CAP_ROUND
	_trail.antialiased = true
	_trail.z_index = -1
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.45, 0.8, 1.0])
	gradient.colors = PackedColorArray([
		Color(0.18, 0.9, 0.78, 0.0),
		Color(0.18, 0.9, 0.78, 0.12),
		Color(1.0, 0.83, 0.28, 0.42),
		Color(1.0, 0.97, 0.88, 0.9),
	])
	_trail.gradient = gradient
	var curve := Curve.new()
	curve.add_point(Vector2(0, 0.1))
	curve.add_point(Vector2(0.7, 0.65))
	curve.add_point(Vector2(1, 1))
	_trail.width_curve = curve
	_trail.visible = false
	add_child(_trail)


func _process(delta: float) -> void:
	_time += delta
	accent = accent.lerp(base_accent, delta * 8.0)
	queue_redraw()


func set_active(active: bool) -> void:
	is_active = active
	_trail.visible = active
	if not active:
		_trail.clear_points()
	else:
		set_velocity(velocity)


func set_velocity(new_velocity: Vector2) -> void:
	velocity = new_velocity
	if is_active and velocity.length_squared() > 1.0:
		_trail.add_point(global_position)
		while _trail.get_point_count() > TRAIL_LENGTH:
			_trail.remove_point(0)


func add_trail_point() -> void:
	if not is_active:
		return
	_trail.add_point(global_position)
	while _trail.get_point_count() > TRAIL_LENGTH:
		_trail.remove_point(0)


func clear_trail() -> void:
	_trail.clear_points()


func reset_to(point: Vector2) -> void:
	position = point
	velocity = Vector2.ZERO
	clear_trail()
	scale = Vector2.ONE


func glow(color: Color, strength: float = 1.0) -> void:
	accent = color
	if strength > 0.5:
		if _pop_tween and _pop_tween.is_valid():
			_pop_tween.kill()
		_pop_tween = create_tween()
		_pop_tween.tween_property(self, "scale", Vector2(1.28, 1.28), 0.05)
		_pop_tween.tween_property(self, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _draw() -> void:
	var pulse := 1.0 + sin(_time * 8.0) * 0.04
	draw_circle(Vector2(3, 6), radius + 3.0, Color(0, 0, 0, 0.28))
	draw_circle(Vector2.ZERO, (radius + 9.0) * pulse, Color(accent.r, accent.g, accent.b, 0.12))
	draw_circle(Vector2.ZERO, radius + 4.0, Color(0.06, 0.07, 0.16, 0.9))
	draw_circle(Vector2.ZERO, radius, Color("#FFF8E9"))
	draw_arc(Vector2.ZERO, radius - 2.0, 0.0, TAU, 32, accent, 3.0, true)
	draw_circle(Vector2(-3.5, -4.0), 3.4, Color(1, 1, 1, 0.95))
	draw_circle(Vector2(4.0, 4.5), 1.6, Color(1, 0.83, 0.28, 0.55))
