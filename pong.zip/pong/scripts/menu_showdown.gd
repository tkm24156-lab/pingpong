extends Node2D
## Looping choreographed duel behind the main menu.

class MenuPaddle extends Node2D:
	var accent := Color("#2EE6C8")
	var facing := 1.0
	var blade_radius := 34.0

	func _draw() -> void:
		var handle_dir := Vector2(-facing, 0.35).normalized()
		var handle_start := handle_dir * blade_radius * 0.74
		var handle_end := handle_dir * (blade_radius + 34.0)
		draw_line(handle_start + Vector2(3, 5), handle_end + Vector2(3, 5), Color(0, 0, 0, 0.28), 15.0, true)
		draw_line(handle_start, handle_end, Color("#10122B"), 16.0, true)
		draw_line(handle_start, handle_end, Color("#F2A65A"), 10.0, true)
		draw_line(handle_start + Vector2(0, -2), handle_end + Vector2(0, -2), Color(1, 0.82, 0.58, 0.7), 3.0, true)
		draw_circle(Vector2(4, 6), blade_radius + 3.0, Color(0, 0, 0, 0.28))
		draw_circle(Vector2.ZERO, blade_radius + 3.0, Color("#10122B"))
		draw_circle(Vector2.ZERO, blade_radius, accent.darkened(0.05))
		draw_arc(Vector2.ZERO, blade_radius - 4.0, 0.0, TAU, 40, accent.lightened(0.45), 3.0, true)
		draw_circle(Vector2(-8, -9), 10.0, Color(1, 1, 1, 0.14))
		for i in 3:
			draw_circle(Vector2(12, -10 + i * 12), 2.2, Color(1, 1, 1, 0.18))


var _maya: CharacterView
var _bot: CharacterView
var _maya_paddle: MenuPaddle
var _bot_paddle: MenuPaddle
var _ball: PongBall
var _fx: FXLayer
var _time := 0.0
var _shake := 0.0
var _running := true
var _home_maya := Vector2(192, 592)
var _home_bot := Vector2(1088, 592)


func _ready() -> void:
	z_index = 2
	_build()
	_run_loop()


func _build() -> void:
	_maya = CharacterView.new()
	_maya.character = "maya"
	_maya.facing = 1
	_maya.visual_scale = 1.72
	_maya.position = _home_maya
	add_child(_maya)

	_bot = CharacterView.new()
	_bot.character = "bot"
	_bot.facing = -1
	_bot.visual_scale = 1.72
	_bot.position = _home_bot
	add_child(_bot)

	_maya_paddle = MenuPaddle.new()
	_maya_paddle.accent = ArcadeTheme.TEAL
	_maya_paddle.facing = 1.0
	_maya_paddle.position = Vector2(350, 402)
	_maya_paddle.rotation = -0.28
	add_child(_maya_paddle)

	_bot_paddle = MenuPaddle.new()
	_bot_paddle.accent = ArcadeTheme.CORAL
	_bot_paddle.facing = -1.0
	_bot_paddle.position = Vector2(930, 402)
	_bot_paddle.rotation = 0.28
	add_child(_bot_paddle)

	_ball = PongBall.new()
	_ball.is_active = true
	_ball.position = Vector2(640, 300)
	_ball.z_index = 8
	_ball.visible = false
	add_child(_ball)

	_fx = FXLayer.new()
	add_child(_fx)


func _process(delta: float) -> void:
	_time += delta
	if _shake > 0.0:
		_shake = maxf(0.0, _shake - delta * 2.8)
		position = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * _shake
	else:
		position = Vector2.ZERO
	if _ball.visible:
		_ball.add_trail_point()
	# Idle paddle sway.
	if _maya_paddle and _ball:
		_maya_paddle.rotation = lerp_angle(_maya_paddle.rotation, -0.28 + sin(_time * 1.8) * 0.05, delta * 4.0)
		_bot_paddle.rotation = lerp_angle(_bot_paddle.rotation, 0.28 + sin(_time * 1.8 + 1.2) * 0.05, delta * 4.0)


func _run_loop() -> void:
	await _wait(1.4)
	while _running and is_inside_tree():
		await _perform_volley()
		await _wait(2.3)
		_reset_pose()


func _perform_volley() -> void:
	# Maya charges and serves.
	_ball.visible = true
	_ball.position = Vector2(350, 402)
	_ball.clear_trail()
	_ball.glow(ArcadeTheme.YELLOW, 1.0)
	_maya.show_pose("attack0", 0.5)
	_maya.punch_scale(1.05)
	await _tween_character(_maya, Vector2(238, 592), -0.04, 0.22)
	_maya_paddle.rotation = -0.9
	_paddle_fx(Vector2(352, 395), ArcadeTheme.TEAL)
	Sfx.play_sfx("paddle_hit", -12.0, 1.22)
	await _wait(0.12)
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(_ball, "position", Vector2(930, 360), 0.38).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tween.tween_property(_maya, "position", _home_maya, 0.3)
	await tween.finished
	if not _running or not is_inside_tree():
		return

	# Bot barely returns it.
	_bot.show_pose("hit", 0.35)
	_bot.punch_scale(1.1)
	_bot.position = Vector2(1130, 592)
	_bot_paddle.rotation = 0.8
	_paddle_fx(Vector2(928, 368), ArcadeTheme.CORAL)
	_comic("PING!", Vector2(982, 292), ArcadeTheme.CORAL)
	Sfx.play_sfx("paddle_hit", -9.0, 0.86)
	_shake = 7.0
	_fx.flash(Color(1, 1, 1, 1), 0.12, 7.0)
	await _wait(0.08)
	_ball.glow(ArcadeTheme.CORAL, 0.8)
	tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(_ball, "position", Vector2(350, 360), 0.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tween.tween_property(_bot, "position", _home_bot, 0.24)
	await tween.finished
	if not _running or not is_inside_tree():
		return

	# Maya ducks, then launches the finishing smash.
	_maya.show_pose("duck", 0.3)
	await _wait(0.2)
	_maya.show_pose("attack2", 0.45)
	_maya.punch_scale(1.14)
	_maya.position = Vector2(260, 592)
	_maya_paddle.rotation = -1.25
	_ball.glow(ArcadeTheme.YELLOW, 1.0)
	_fx.ring(Vector2(370, 365), ArcadeTheme.YELLOW, 18.0, 180.0, 5.0)
	_fx.burst(Vector2(370, 365), ArcadeTheme.YELLOW, 26, 520.0, Vector2.RIGHT)
	_comic("POW!", Vector2(402, 315), ArcadeTheme.YELLOW)
	Sfx.play_sfx("smash", -6.0, 0.95)
	_shake = 10.0
	await _wait(0.1)
	tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(_ball, "position", Vector2(930, 340), 0.18).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tween.tween_property(_maya, "position", _home_maya, 0.3)
	await tween.finished
	if not _running or not is_inside_tree():
		return

	# The bot gets tagged and the crowd erupts.
	_bot.show_pose("hurt", 0.7)
	_bot.position = Vector2(1180, 592)
	_ball.visible = false
	_fx.flash(ArcadeTheme.YELLOW, 0.24, 4.0)
	_fx.burst(Vector2(985, 370), ArcadeTheme.CORAL, 34, 620.0, Vector2.RIGHT)
	_fx.ring(Vector2(985, 370), ArcadeTheme.CORAL, 24.0, 240.0, 6.0)
	_fx.confetti(Vector2(640, 120), 34, 860.0)
	_comic("BONK!", Vector2(960, 292), ArcadeTheme.CORAL)
	Sfx.play_sfx("point", -8.0, 0.9)
	_shake = 13.0
	await _wait(0.55)
	_maya.show_pose("cheer0", 1.2)
	_bot.show_pose("down", 1.1)
	await _wait(1.4)
	if not _running or not is_inside_tree():
		return
	# Quick rematch taunt.
	_maya.show_pose("talk", 0.45)
	_bot.show_pose("think", 0.55)


func _paddle_fx(at: Vector2, color: Color) -> void:
	_fx.ring(at, color, 10.0, 70.0, 3.0)
	_fx.burst(at, color, 12, 280.0, Vector2.RIGHT if at.x < 640 else Vector2.LEFT)


func _comic(text: String, at: Vector2, color: Color) -> void:
	var label := Label.new()
	label.text = text
	label.add_theme_font_override("font", ArcadeTheme.DISPLAY_FONT)
	label.add_theme_font_size_override("font_size", 46)
	label.add_theme_color_override("font_color", color)
	label.add_theme_color_override("font_outline_color", ArcadeTheme.INK_DEEP)
	label.add_theme_constant_override("outline_size", 9)
	label.add_theme_constant_override("shadow_offset_x", 0)
	label.add_theme_constant_override("shadow_offset_y", 5)
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.35))
	label.position = at
	label.rotation = -0.12
	label.z_index = 40
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(label)
	label.pivot_offset = label.get_combined_minimum_size() * 0.5
	label.scale = Vector2(0.4, 0.4)
	var tween := create_tween().set_parallel(true)
	tween.tween_property(label, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(label, "position:y", at.y - 38.0, 0.8).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tween.tween_property(label, "modulate:a", 0.0, 0.28).set_delay(0.52)
	tween.chain().tween_callback(label.queue_free)


func _tween_character(character: CharacterView, target: Vector2, rotation: float, duration: float) -> void:
	var tween := create_tween().set_parallel(true)
	tween.tween_property(character, "position", target, duration).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(character, "rotation", rotation, duration)
	await tween.finished


func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds).timeout


func _reset_pose() -> void:
	if not is_inside_tree():
		return
	_ball.visible = false
	_ball.clear_trail()
	_maya.position = _home_maya
	_bot.position = _home_bot
	_maya.rotation = 0.0
	_bot.rotation = 0.0
	_maya.show_pose("idle", 0.0)
	_bot.show_pose("idle", 0.0)


func _exit_tree() -> void:
	_running = false
