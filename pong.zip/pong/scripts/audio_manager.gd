extends Node
## Small pooled audio engine for effects, music, and stingers.

const SFX_POOL_SIZE := 12

const SFX_STREAMS := {
	"click": preload("res://assets/audio/ui_click.ogg"),
	"confirm": preload("res://assets/audio/ui_confirm.ogg"),
	"back": preload("res://assets/audio/ui_back.ogg"),
	"switch": preload("res://assets/audio/ui_switch.ogg"),
	"error": preload("res://assets/audio/ui_error.ogg"),
	"paddle_hit": preload("res://assets/audio/hit_paddle.ogg"),
	"soft_hit": preload("res://assets/audio/hit_soft.ogg"),
	"wall_hit": preload("res://assets/audio/wall_hit.ogg"),
	"smash": preload("res://assets/audio/smash.ogg"),
	"guard": preload("res://assets/audio/guard.ogg"),
	"point": preload("res://assets/audio/point.ogg"),
	"stinger_a": preload("res://assets/audio/jingle_a.ogg"),
	"stinger_b": preload("res://assets/audio/jingle_b.ogg"),
}

const MUSIC_STREAMS := {
	"menu": preload("res://assets/audio/music_menu.ogg"),
	"gameplay": preload("res://assets/audio/music_gameplay.ogg"),
}

var _sfx_players: Array[AudioStreamPlayer] = []
var _music_a: AudioStreamPlayer
var _music_b: AudioStreamPlayer
var _active_music: AudioStreamPlayer
var _inactive_music: AudioStreamPlayer
var _current_track := ""
var _music_tween: Tween
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rng.randomize()
	for i in SFX_POOL_SIZE:
		var player := AudioStreamPlayer.new()
		player.name = "Sfx%d" % i
		player.bus = "Master"
		player.process_mode = Node.PROCESS_MODE_ALWAYS
		add_child(player)
		_sfx_players.append(player)
	_music_a = _make_music_player("MusicA")
	_music_b = _make_music_player("MusicB")
	_active_music = _music_a
	_inactive_music = _music_b
	_configure_music_loop(_music_a)
	_configure_music_loop(_music_b)


func _make_music_player(name: String) -> AudioStreamPlayer:
	var player := AudioStreamPlayer.new()
	player.name = name
	player.bus = "Master"
	player.volume_db = -80.0
	player.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(player)
	return player


func _configure_music_loop(player: AudioStreamPlayer) -> void:
	# AudioStreamOggVorbis is imported looping at runtime for music only.
	pass


func play_sfx(sound: String, volume_db: float = 0.0, pitch_scale: float = 1.0) -> void:
	if not GameState.sound_enabled:
		return
	if not SFX_STREAMS.has(sound):
		push_warning("Unknown sound: %s" % sound)
		return
	var stream: AudioStream = SFX_STREAMS[sound]
	for player in _sfx_players:
		if not player.playing:
			player.stream = stream
			player.volume_db = volume_db
			player.pitch_scale = clampf(pitch_scale * _rng.randf_range(0.97, 1.03), 0.6, 1.7)
			player.play()
			return
	# If the pool is exhausted, recycle the first player.
	var fallback := _sfx_players[0]
	fallback.stream = stream
	fallback.volume_db = volume_db
	fallback.pitch_scale = pitch_scale
	fallback.play()


func play_music(track: String, fade_time: float = 0.55) -> void:
	if _current_track == track and _active_music.playing:
		return
	if not MUSIC_STREAMS.has(track):
		return
	_current_track = track
	if not GameState.sound_enabled:
		return
	var stream: AudioStream = MUSIC_STREAMS[track].duplicate()
	if stream is AudioStreamOggVorbis:
		stream.loop = true
		stream.loop_offset = 0.0
	var old_music := _active_music
	var new_music := _inactive_music
	_active_music = new_music
	_inactive_music = old_music
	new_music.stream = stream
	new_music.volume_db = -80.0
	new_music.play()
	if _music_tween and _music_tween.is_valid():
		_music_tween.kill()
	_music_tween = create_tween().set_parallel(true)
	_music_tween.tween_property(new_music, "volume_db", -17.0, fade_time)
	_music_tween.tween_property(old_music, "volume_db", -80.0, fade_time)
	_music_tween.chain().tween_callback(old_music.stop)


func stop_music(fade_time: float = 0.35) -> void:
	_current_track = ""
	if _music_tween and _music_tween.is_valid():
		_music_tween.kill()
	_music_tween = create_tween()
	_music_tween.tween_property(_active_music, "volume_db", -80.0, fade_time)
	_music_tween.tween_callback(_active_music.stop)


func pause_music(paused: bool) -> void:
	_active_music.stream_paused = paused
	_inactive_music.stream_paused = paused


func play_stinger(win: bool) -> void:
	play_sfx("stinger_a" if win else "stinger_b", -2.0)


func apply_sound_setting() -> void:
	set_process(true)
	if not GameState.sound_enabled:
		_active_music.volume_db = -80.0
	elif _active_music.playing:
		_active_music.volume_db = -17.0
