class_name MatchRules
extends RefCounted
## Pure scoring rules: first to 11, win by 2; best-of-three rounds.

const WIN_SCORE := 11
const WIN_MARGIN := 2
const ROUNDS_TO_WIN := 2


static func round_is_won(player_score: int, ai_score: int) -> bool:
	var leading := maxi(player_score, ai_score)
	var margin := absi(player_score - ai_score)
	return leading >= WIN_SCORE and margin >= WIN_MARGIN


static func match_is_won(player_rounds: int, ai_rounds: int) -> bool:
	return player_rounds >= ROUNDS_TO_WIN or ai_rounds >= ROUNDS_TO_WIN


static func is_deuce(player_score: int, ai_score: int) -> bool:
	return player_score >= WIN_SCORE - 1 and ai_score >= WIN_SCORE - 1 and player_score == ai_score


static func point_status(player_score: int, ai_score: int) -> String:
	## Returns "game", "deuce", "advantage_player", "advantage_ai", or "normal".
	if is_deuce(player_score, ai_score):
		return "deuce"
	if player_score >= WIN_SCORE - 1 and ai_score >= WIN_SCORE - 1:
		if player_score > ai_score:
			return "advantage_player"
		if ai_score > player_score:
			return "advantage_ai"
	if not round_is_won(player_score, ai_score):
		var player_can_win := player_score >= WIN_SCORE - 1 and player_score >= ai_score + 1
		var ai_can_win := ai_score >= WIN_SCORE - 1 and ai_score >= player_score + 1
		if player_can_win or ai_can_win:
			return "game"
	return "normal"


static func match_point_for(player_rounds: int, ai_rounds: int, player_score: int, ai_score: int) -> bool:
	## True when the player can win the whole match by taking the next point.
	if player_rounds < ROUNDS_TO_WIN - 1:
		return false
	var hypothetical_player := player_score + 1
	return round_is_won(hypothetical_player, ai_score)


static func match_point_against(player_rounds: int, ai_rounds: int, player_score: int, ai_score: int) -> bool:
	if ai_rounds < ROUNDS_TO_WIN - 1:
		return false
	var hypothetical_ai := ai_score + 1
	return round_is_won(player_score, hypothetical_ai)


static func clamp_score_for_display(score: int) -> String:
	return str(score).pad_zeros(2)
