class_name CooldownAbility
extends RefCounted
## Cooldown + active-window helper used by Smash and Guard.

var cooldown_total := 5.0
var active_duration := 0.4
var cooldown_left := 0.0
var active_left := 0.0


func _init(p_cooldown: float = 5.0, p_active_duration: float = 0.4) -> void:
	cooldown_total = maxf(p_cooldown, 0.01)
	active_duration = maxf(p_active_duration, 0.01)


func trigger() -> bool:
	if not is_ready():
		return false
	cooldown_left = cooldown_total
	active_left = active_duration
	return true


func tick(delta: float) -> void:
	cooldown_left = maxf(0.0, cooldown_left - delta)
	active_left = maxf(0.0, active_left - delta)


func end_active() -> void:
	active_left = 0.0


func is_active() -> bool:
	return active_left > 0.0


func is_ready() -> bool:
	return cooldown_left <= 0.0 and active_left <= 0.0


func cooldown_ratio() -> float:
	return clampf(1.0 - cooldown_left / cooldown_total, 0.0, 1.0)


func reset() -> void:
	cooldown_left = 0.0
	active_left = 0.0
