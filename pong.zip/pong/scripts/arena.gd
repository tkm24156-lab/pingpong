extends Node2D
## Procedural cartoon arena. Two modes share the same stadium backdrop.

const COURT_LEFT := 70.0
const COURT_RIGHT := 1210.0
const COURT_TOP := 112.0
const COURT_BOTTOM := 648.0

@export_enum("game", "menu") var mode := "game"

var _time := 0.0
var _crowd: Array[Dictionary] = []
var _confetti: Array[Dictionary] = []
var _court_style: StyleBoxFlat
var _court_shadow: StyleBoxFlat
var _menu_floor: StyleBoxFlat
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	z_index = -10
	_rng.seed = 90210
	_build_crowd()
	_build_confetti()
	_court_style = ArcadeTheme._style(Color("#141A3F"), Color("#FFD447"), 28, 6, 22)
	_court_shadow = ArcadeTheme._style(Color(0.02, 0.025, 0.08, 0.65), Color(0, 0, 0, 0), 32, 0, 20)
	_menu_floor = ArcadeTheme._style(Color(0.05, 0.07, 0.17, 0.72), Color(1.0, 0.83, 0.28, 0.28), 220, 3, 26)
	queue_redraw()


func _process(delta: float) -> void:
	_time += delta
	queue_redraw()


func _build_crowd() -> void:
	var colors := [
		Color("#FF5D73"), Color("#FFD447"), Color("#2EE6C8"), Color("#5CC8FF"),
		Color("#FF8FB1"), Color("#8E7DFF"), Color("#FFF7E8"), Color("#61E8A8"),
	]
	for band in 2:
		var count := 34
		for i in count:
			var x := 22.0 + i * (36.0 + _rng.randf_range(-5.0, 7.0))
			var y := (30.0 if band == 0 else 690.0) + _rng.randf_range(-10.0, 10.0)
			_crowd.append({
				"pos": Vector2(x, y),
				"color": colors[_rng.randi() % colors.size()],
				"phase": _rng.randf_range(0.0, TAU),
				"size": _rng.randf_range(5.0, 9.0),
				"band": band,
			})
	for i in 28:
		var side := -1.0 if i % 2 == 0 else 1.0
		var x := 640.0 + side * _rng.randf_range(560.0, 700.0)
		var y := _rng.randf_range(120.0, 620.0)
		_crowd.append({
			"pos": Vector2(x, y),
			"color": colors[_rng.randi() % colors.size()],
			"phase": _rng.randf_range(0.0, TAU),
			"size": _rng.randf_range(3.5, 6.0),
			"band": 2,
		})


func _build_confetti() -> void:
	var colors := [ArcadeTheme.YELLOW, ArcadeTheme.CORAL, ArcadeTheme.TEAL, ArcadeTheme.BLUE, ArcadeTheme.PINK]
	for i in 26:
		_confetti.append({
			"pos": Vector2(_rng.randf_range(20, 1260), _rng.randf_range(20, 700)),
			"speed": _rng.randf_range(5.0, 16.0),
			"phase": _rng.randf_range(0.0, TAU),
			"color": colors[_rng.randi() % colors.size()],
			"size": _rng.randf_range(2.0, 5.0),
			"rotate": _rng.randf_range(-2.0, 2.0),
		})


func _draw() -> void:
	_draw_background()
	if mode == "menu":
		_draw_menu_stage()
	else:
		_draw_court()


func _draw_background() -> void:
	# Layered gradient sky.
	var top := Color("#17153B")
	var middle := Color("#172A50")
	var bottom := Color("#0D545A")
	for i in 32:
		var ratio := float(i) / 31.0
		var color := top.lerp(middle, ratio * 2.0) if ratio < 0.5 else middle.lerp(bottom, (ratio - 0.5) * 2.0)
		draw_rect(Rect2(0, i * 23.0, 1280, 24), color)

	# Sunburst spotlight.
	var burst_center := Vector2(640, 380)
	for i in 20:
		var angle := _time * 0.025 + i * TAU / 20.0
		var next := angle + TAU / 40.0
		var points := PackedVector2Array([
			burst_center,
			burst_center + Vector2(cos(angle), sin(angle)) * 900.0,
			burst_center + Vector2(cos(next), sin(next)) * 900.0,
		])
		draw_colored_polygon(points, Color(1, 1, 1, 0.022 if i % 2 == 0 else 0.0))

	# Halftone dots.
	for i in 26:
		var x := 34.0 + (i % 13) * 98.0
		var y := 80.0 + (i / 13) * 570.0
		draw_circle(Vector2(x, y), 2.0, Color(1, 1, 1, 0.055))

	# Stadium beams and top signage.
	draw_rect(Rect2(0, 0, 1280, 8), Color("#FFD447"))
	draw_rect(Rect2(0, 704, 1280, 16), Color("#10122B"))
	draw_line(Vector2(0, 96), Vector2(1280, 96), Color(1, 1, 1, 0.06), 2.0)
	draw_line(Vector2(0, 654), Vector2(1280, 654), Color(1, 1, 1, 0.06), 2.0)

	# Light cones from the ceiling.
	for i in 2:
		var origin := Vector2(90.0 if i == 0 else 1190.0, -20.0)
		var target_a := Vector2(250.0 if i == 0 else 1030.0, 700.0)
		var target_b := Vector2(530.0 if i == 0 else 750.0, 700.0)
		var points := PackedVector2Array([origin, target_a, target_b])
		draw_colored_polygon(points, Color(0.45, 1.0, 0.92, 0.035))
		draw_line(origin, target_a, Color(0.55, 1.0, 0.94, 0.06), 2.0)
		draw_line(origin, target_b, Color(0.55, 1.0, 0.94, 0.04), 2.0)
		draw_circle(origin + Vector2(0, 8), 14.0, Color("#2EE6C8"))
		draw_circle(origin + Vector2(0, 8), 27.0, Color(0.18, 0.9, 0.78, 0.12))

	# Crowd.
	for fan in _crowd:
		var bob := sin(_time * 2.8 + float(fan["phase"])) * (2.0 if int(fan["band"]) < 2 else 1.0)
		var pos: Vector2 = fan["pos"] + Vector2(0, bob)
		var color: Color = fan["color"]
		var size: float = fan["size"]
		draw_circle(pos, size, Color(color.r, color.g, color.b, 0.55))
		draw_rect(Rect2(pos + Vector2(-size * 0.8, size * 0.8), Vector2(size * 1.6, size * 1.1)), Color(color.r, color.g, color.b, 0.32))

	# Floating confetti and ambient dots.
	for piece in _confetti:
		var pos: Vector2 = piece["pos"]
		var drift := sin(_time * 0.7 + float(piece["phase"])) * 18.0
		var y := fposmod(pos.y + _time * float(piece["speed"]), 720.0)
		var color: Color = piece["color"]
		var size: float = piece["size"]
		draw_set_transform(Vector2(pos.x + drift, y), _time * float(piece["rotate"]) + float(piece["phase"]), Vector2.ONE)
		draw_rect(Rect2(-size, -size * 0.55, size * 2.0, size * 1.1), Color(color.r, color.g, color.b, 0.22))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# Side graffiti-style PONG PANIC marks.
	var font := ArcadeTheme.DISPLAY_FONT
	draw_set_transform(Vector2(30, 200), -PI / 2.0, Vector2.ONE)
	draw_string(font, Vector2.ZERO, "PONG PANIC", HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color(1, 1, 1, 0.08))
	draw_set_transform(Vector2(1266, 600), PI / 2.0, Vector2.ONE)
	draw_string(font, Vector2.ZERO, "RALLY CITY", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 1, 1, 0.07))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_court() -> void:
	var court_rect := Rect2(COURT_LEFT, COURT_TOP, COURT_RIGHT - COURT_LEFT, COURT_BOTTOM - COURT_TOP)
	draw_style_box(_court_shadow, court_rect.grow(10.0))
	draw_style_box(_court_style, court_rect)

	# Soft team glows in each half.
	for i in 10:
		var alpha := 0.028 - i * 0.0024
		draw_rect(Rect2(COURT_LEFT + 8 + i * 5, COURT_TOP + 8, 170 - i * 10, court_rect.size.y - 16), Color(0.18, 0.90, 0.78, maxf(alpha, 0.0)))
		draw_rect(Rect2(COURT_RIGHT - 8 - i * 5 - (170 - i * 10), COURT_TOP + 8, 170 - i * 10, court_rect.size.y - 16), Color(1.0, 0.36, 0.45, maxf(alpha, 0.0)))

	# Giant faded wordmark.
	var font := ArcadeTheme.DISPLAY_FONT
	draw_set_transform(Vector2(640, 400), 0.0, Vector2(1.0, 1.0))
	draw_string(font, Vector2(-240, 60), "PONG", HORIZONTAL_ALIGNMENT_CENTER, 480, 190, Color(1, 1, 1, 0.035))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# Court markings.
	var center_x := (COURT_LEFT + COURT_RIGHT) * 0.5
	var center_y := (COURT_TOP + COURT_BOTTOM) * 0.5
	var inner_top := COURT_TOP + 16.0
	var inner_bottom := COURT_BOTTOM - 16.0
	for i in 11:
		var y := inner_top + i * ((inner_bottom - inner_top) / 11.0)
		draw_line(Vector2(center_x, y), Vector2(center_x, y + 26.0), Color(1, 1, 1, 0.15), 3.0)
	draw_arc(Vector2(center_x, center_y), 92.0, 0.0, TAU, 64, Color(1, 1, 1, 0.10), 3.0, true)
	draw_arc(Vector2(center_x, center_y), 8.0, 0.0, TAU, 24, Color(1, 0.83, 0.28, 0.55), 3.0, true)

	# Goal zones, side chevrons, and baseline accents.
	draw_rect(Rect2(COURT_LEFT, COURT_TOP, 7, COURT_BOTTOM - COURT_TOP), Color(0.18, 0.90, 0.78, 0.55))
	draw_rect(Rect2(COURT_RIGHT - 7, COURT_TOP, 7, COURT_BOTTOM - COURT_TOP), Color(1.0, 0.36, 0.45, 0.55))
	for i in 3:
		var y := 250.0 + i * 70.0
		_draw_chevron(Vector2(COURT_LEFT + 38, y), 1.0, Color(0.18, 0.90, 0.78, 0.18 + i * 0.03))
		_draw_chevron(Vector2(COURT_RIGHT - 38, y), -1.0, Color(1.0, 0.36, 0.45, 0.18 + i * 0.03))

	# Top and bottom court highlights.
	draw_line(Vector2(COURT_LEFT + 30, COURT_TOP + 6), Vector2(COURT_RIGHT - 30, COURT_TOP + 6), Color(1, 1, 1, 0.12), 2.0)
	draw_line(Vector2(COURT_LEFT + 30, COURT_BOTTOM - 6), Vector2(COURT_RIGHT - 30, COURT_BOTTOM - 6), Color(0, 0, 0, 0.20), 3.0)


func _draw_chevron(at: Vector2, direction: float, color: Color) -> void:
	draw_line(at, at + Vector2(18.0 * direction, -14.0), color, 4.0, true)
	draw_line(at, at + Vector2(18.0 * direction, 14.0), color, 4.0, true)


func _draw_menu_stage() -> void:
	# Arena floor with concentric perspective rings.
	var center := Vector2(640, 710)
	draw_style_box(_menu_floor, Rect2(40, 520, 1200, 360))
	for i in 4:
		var radius := 230.0 + i * 95.0
		draw_arc(center, radius, PI, TAU, 72, Color(1, 0.83, 0.28, 0.10 - i * 0.015), 4.0, true)
		draw_arc(center, radius + 2.0, PI, TAU, 72, Color(0.18, 0.90, 0.78, 0.04), 2.0, true)
	draw_line(Vector2(40, 606), Vector2(1240, 606), Color(0.18, 0.90, 0.78, 0.14), 2.0)
	draw_line(Vector2(40, 610), Vector2(1240, 610), Color(0, 0, 0, 0.25), 4.0)

	# Spotlight pools for both duelists.
	for i in 2:
		var x := 175.0 if i == 0 else 1105.0
		var color := ArcadeTheme.TEAL if i == 0 else ArcadeTheme.CORAL
		for j in 5:
			draw_circle(Vector2(x, 590), 96.0 + j * 18.0, Color(color.r, color.g, color.b, 0.018))
		draw_line(Vector2(x, 30), Vector2(x, 700), Color(color.r, color.g, color.b, 0.045), 2.0)

	# Big VS burst behind the menu panel.
	var center_panel := Vector2(640, 270)
	for i in 16:
		var angle := i * TAU / 16.0 + _time * 0.08
		var next := angle + TAU / 32.0
		var points := PackedVector2Array([
			center_panel + Vector2(cos(angle), sin(angle)) * 70.0,
			center_panel + Vector2(cos(angle), sin(angle)) * 260.0,
			center_panel + Vector2(cos(next), sin(next)) * 260.0,
		])
		draw_colored_polygon(points, Color(1, 0.83, 0.28, 0.025 if i % 2 == 0 else 0.0))

	# Floating table tennis balls in the background.
	for i in 5:
		var angle := _time * 0.13 + i * 1.7
		var pos := Vector2(640 + cos(angle) * (360 + i * 28), 280 + sin(angle * 1.4) * 140)
		draw_circle(pos, 7.0, Color(1, 0.97, 0.9, 0.07))
		draw_arc(pos, 9.0, 0.0, TAU, 20, Color(1, 0.83, 0.28, 0.09), 1.5, true)
