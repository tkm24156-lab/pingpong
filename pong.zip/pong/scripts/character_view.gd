class_name CharacterView
extends Node2D
## Sprite-based duelist with simple pose state and idle motion.

const POSE_PATH := "res://assets/sprites/characters/%s/%s.png"

@export var character := "maya"
@export var facing := 1
@export var visual_scale := 0.92
@export var bob_amount := 2.5

var current_pose := "idle"
var _sprite: Sprite2D
var _shadow: Sprite2D
var _time := 0.0
var _pose_timer := 0.0
var _base_pose := "idle"
var _pose_tween: Tween
var _textures := {}


func _ready() -> void:
	z_index = 3
	_shadow = Sprite2D.new()
	_shadow.name = "Shadow"
	var shadow_image := GradientTexture2D.new()
	var gradient := Gradient.new()
	gradient.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	gradient.colors = PackedColorArray([Color(0, 0, 0, 0.38), Color(0, 0, 0, 0.22), Color(0, 0, 0, 0)])
	shadow_image.gradient = gradient
	shadow_image.fill = GradientTexture2D.FILL_RADIAL
	shadow_image.fill_from = Vector2(0.5, 0.5)
	shadow_image.fill_to = Vector2(1.0, 0.5)
	shadow_image.width = 128
	shadow_image.height = 128
	_shadow.texture = shadow_image
	_shadow.scale = Vector2(1.45 * visual_scale, 0.42)
	_shadow.position = Vector2(0, 4)
	_shadow.z_index = -2
	add_child(_shadow)

	_sprite = Sprite2D.new()
	_sprite.name = "Sprite"
	_sprite.centered = true
	_sprite.flip_h = facing < 0
	_sprite.scale = Vector2(visual_scale, visual_scale)
	_sprite.position = Vector2(0, -128.0 * visual_scale)
	add_child(_sprite)

	_set_pose_texture("idle")
	_play_entrance()


func _process(delta: float) -> void:
	_time += delta
	if _pose_timer > 0.0:
		_pose_timer -= delta
		if _pose_timer <= 0.0:
			_set_pose_texture(_base_pose)
	var bob := sin(_time * 2.1 + position.x * 0.01) * bob_amount
	if _sprite:
		_sprite.position.y = -128.0 * visual_scale + bob
		_sprite.rotation = sin(_time * 1.3 + position.x * 0.01) * 0.012


func show_pose(pose: String, duration: float = 0.28) -> void:
	if not FileAccess.file_exists(POSE_PATH % [character, pose]):
		pose = "idle"
	_set_pose_texture(pose)
	_pose_timer = duration
	if duration <= 0.0:
		_base_pose = pose


func react(kind: String) -> void:
	match kind:
		"hit":
			show_pose("attack0", 0.20)
		"smash":
			show_pose("attack2", 0.34)
		"hurt":
			show_pose("hurt", 0.55)
		"cheer":
			show_pose("cheer0", 0.85)
		"sad":
			show_pose("down", 1.0)
		"dash":
			show_pose("run0", 0.24)
		"idle":
			_base_pose = "idle"
			_set_pose_texture("idle")


func set_base_pose(pose: String) -> void:
	_base_pose = pose
	if _pose_timer <= 0.0:
		_set_pose_texture(pose)


func punch_scale(strength: float = 1.08) -> void:
	if _pose_tween and _pose_tween.is_valid():
		_pose_tween.kill()
	_pose_tween = create_tween()
	_pose_tween.tween_property(_sprite, "scale", Vector2(visual_scale, visual_scale) * strength, 0.07)
	_pose_tween.tween_property(_sprite, "scale", Vector2(visual_scale, visual_scale), 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _set_pose_texture(pose: String) -> void:
	current_pose = pose
	if not _textures.has(pose):
		var path := POSE_PATH % [character, pose]
		if not ResourceLoader.exists(path):
			path = POSE_PATH % [character, "idle"]
		_textures[pose] = load(path)
	if _sprite:
		_sprite.texture = _textures[pose]


func _play_entrance() -> void:
	if not _sprite:
		return
	_sprite.modulate.a = 0.0
	_sprite.scale = Vector2(visual_scale * 0.82, visual_scale * 0.82)
	var tween := create_tween().set_parallel(true)
	tween.tween_property(_sprite, "modulate:a", 1.0, 0.35)
	tween.tween_property(_sprite, "scale", Vector2(visual_scale, visual_scale), 0.48).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
