extends Node2D
## Main menu: cartoon showdown, difficulty choice, and entry point into a match.

@onready var arena: Node2D = $Arena
@onready var showdown: Node2D = $Showdown

var _ui: CanvasLayer
var _root: Control
var _difficulty_buttons := {}
var _tagline: Label
var _play_button: Button
var _sound_button: Button
var _how_to_overlay: Control
var _how_to_panel: PanelContainer
var _fade_overlay: ColorRect
var _leaving := false
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.randomize()
	get_tree().paused = false
	Sfx.play_music("menu")
	_build_ui()
	_update_difficulty_ui()
	_start_logo_loop()
	_fade_in()


func _build_ui() -> void:
	_ui = CanvasLayer.new()
	_ui.name = "UI"
	_ui.layer = 10
	add_child(_ui)
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.theme = ArcadeTheme.make_theme()
	_ui.add_child(_root)

	_build_top_badges()
	_build_logo()
	_build_menu_panel()
	_build_how_to_play()
	_build_fade_overlay()


func _build_top_badges() -> void:
	var edition := Label.new()
	edition.text = "RALLY CITY PRESENTS  •  v1.0"
	edition.theme_type_variation = "MutedLabel"
	edition.position = Vector2(28, 18)
	edition.add_theme_font_size_override("font_size", 11)
	_root.add_child(edition)

	_how_to_open_button = Button.new()
	_how_to_open_button.text = "HOW TO PLAY"
	_how_to_open_button.theme_type_variation = "GhostButton"
	_how_to_open_button.position = Vector2(956, 16)
	_how_to_open_button.custom_minimum_size = Vector2(146, 40)
	_how_to_open_button.add_theme_font_size_override("font_size", 16)
	_how_to_open_button.pressed.connect(_open_how_to_play)
	_root.add_child(_how_to_open_button)

	_sound_button = Button.new()
	_sound_button.theme_type_variation = "GhostButton"
	_sound_button.position = Vector2(1110, 16)
	_sound_button.custom_minimum_size = Vector2(140, 40)
	_sound_button.add_theme_font_size_override("font_size", 16)
	_sound_button.pressed.connect(_toggle_sound)
	_root.add_child(_sound_button)
	_update_sound_button()


var _how_to_open_button: Button


func _build_logo() -> void:
	var group := VBoxContainer.new()
	group.position = Vector2(0, 22)
	group.custom_minimum_size = Vector2(1280, 0)
	group.alignment = BoxContainer.ALIGNMENT_CENTER
	group.add_theme_constant_override("separation", -24)
	group.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(group)
	group.set_meta("is_logo", true)

	var pong := Label.new()
	pong.text = "PONG"
	pong.theme_type_variation = "LogoLabel"
	pong.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pong.rotation = -0.018
	pong.mouse_filter = Control.MOUSE_FILTER_IGNORE
	group.add_child(pong)

	var panic := Label.new()
	panic.text = "PANIC!"
	panic.theme_type_variation = "DisplayLabel"
	panic.add_theme_font_size_override("font_size", 68)
	panic.add_theme_color_override("font_color", ArcadeTheme.CORAL)
	panic.add_theme_constant_override("outline_size", 12)
	panic.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	panic.rotation = 0.012
	panic.mouse_filter = Control.MOUSE_FILTER_IGNORE
	group.add_child(panic)

	var subtitle := Label.new()
	subtitle.text = "A CARTOON TABLE-TENNIS SHOWDOWN"
	subtitle.theme_type_variation = "PillLabel"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_color_override("font_color", ArcadeTheme.TEAL)
	subtitle.add_theme_font_size_override("font_size", 15)
	subtitle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	group.add_child(subtitle)
	group.set_meta("logo_node", group)


func _start_logo_loop() -> void:
	# Find the logo group by its metadata to keep the builder order flexible.
	var logo_group: VBoxContainer = null
	for child in _root.get_children():
		if child.has_meta("is_logo"):
			logo_group = child
			break
	if not logo_group:
		return
	logo_group.pivot_offset = Vector2(640, 110)
	var tween := create_tween().set_loops()
	tween.tween_property(logo_group, "rotation", 0.012, 2.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(logo_group, "rotation", -0.012, 2.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var bounce := create_tween().set_loops()
	bounce.tween_property(logo_group, "scale", Vector2(1.015, 1.015), 1.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	bounce.tween_property(logo_group, "scale", Vector2.ONE, 1.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _build_menu_panel() -> void:
	var hint := Label.new()
	hint.text = "W / S  MOVE     SPACE  SMASH     SHIFT  GUARD"
	hint.theme_type_variation = "MutedLabel"
	hint.position = Vector2(0, 452)
	hint.custom_minimum_size = Vector2(1280, 0)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_color_override("font_color", Color(1, 1, 1, 0.45))
	_root.add_child(hint)

	var panel := PanelContainer.new()
	panel.theme_type_variation = "GlassPanel"
	panel.position = Vector2(370, 480)
	panel.custom_minimum_size = Vector2(540, 218)
	_root.add_child(panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 22)
	margin.add_theme_constant_override("margin_right", 22)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 16)
	panel.add_child(margin)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	margin.add_child(column)

	var header := HBoxContainer.new()
	column.add_child(header)
	var choose := Label.new()
	choose.text = "CHOOSE YOUR CHALLENGE"
	choose.theme_type_variation = "PillLabel"
	choose.add_theme_color_override("font_color", ArcadeTheme.YELLOW)
	choose.add_theme_font_size_override("font_size", 14)
	choose.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(choose)
	var format := Label.new()
	format.text = "BEST OF 3"
	format.theme_type_variation = "MutedLabel"
	format.add_theme_font_size_override("font_size", 11)
	format.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	header.add_child(format)

	var difficult_row := HBoxContainer.new()
	difficult_row.add_theme_constant_override("separation", 8)
	column.add_child(difficult_row)
	for id in ["easy", "medium", "hard"]:
		var button := Button.new()
		button.text = GameState.DIFFICULTIES[id]["label"]
		button.theme_type_variation = "DifficultyButton"
		button.custom_minimum_size = Vector2(0, 52)
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.add_theme_font_size_override("font_size", 22)
		button.set_meta("difficulty", id)
		button.pressed.connect(_select_difficulty.bind(id))
		difficult_row.add_child(button)
		_difficulty_buttons[id] = button

	_tagline = Label.new()
	_tagline.theme_type_variation = "MutedLabel"
	_tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_tagline.add_theme_font_size_override("font_size", 12)
	_tagline.custom_minimum_size = Vector2(0, 30)
	_tagline.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(_tagline)

	_play_button = Button.new()
	_play_button.text = "PLAY MATCH"
	_play_button.theme_type_variation = "PrimaryButton"
	_play_button.custom_minimum_size = Vector2(0, 56)
	_play_button.add_theme_font_size_override("font_size", 30)
	_play_button.pressed.connect(_start_match)
	column.add_child(_play_button)
	_play_button.grab_focus()


func _select_difficulty(id: String) -> void:
	if _leaving:
		return
	GameState.set_difficulty(id)
	Sfx.play_sfx("switch", -6.0, 1.05)
	_update_difficulty_ui()


func _update_difficulty_ui() -> void:
	for id in _difficulty_buttons.keys():
		var button: Button = _difficulty_buttons[id]
		button.theme_type_variation = "DifficultySelected" if id == GameState.difficulty else "DifficultyButton"
	_tagline.text = GameState.get_difficulty_tagline()
	_tagline.add_theme_color_override("font_color", GameState.get_difficulty_color())


func _toggle_sound() -> void:
	GameState.toggle_sound()
	Sfx.apply_sound_setting()
	Sfx.play_sfx("click", -3.0)
	_update_sound_button()


func _update_sound_button() -> void:
	if _sound_button:
		_sound_button.text = "SOUND  ON" if GameState.sound_enabled else "SOUND  OFF"


func _start_match() -> void:
	if _leaving:
		return
	_leaving = true
	_play_button.disabled = true
	Sfx.play_sfx("confirm", -2.0)
	_fade_overlay.visible = true
	_fade_overlay.color = Color(ArcadeTheme.INK_DEEP.r, ArcadeTheme.INK_DEEP.g, ArcadeTheme.INK_DEEP.b, 0.0)
	var tween := create_tween()
	tween.tween_property(_fade_overlay, "color:a", 1.0, 0.32)
	await tween.finished
	get_tree().change_scene_to_file("res://scenes/game.tscn")


func _build_how_to_play() -> void:
	_how_to_overlay = Control.new()
	_how_to_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_how_to_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	_how_to_overlay.visible = false
	_root.add_child(_how_to_overlay)

	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.025, 0.08, 0.78)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_how_to_overlay.add_child(dim)

	_how_to_panel = PanelContainer.new()
	_how_to_panel.theme_type_variation = "ModalPanel"
	_how_to_panel.position = Vector2(208, 70)
	_how_to_panel.custom_minimum_size = Vector2(864, 580)
	_how_to_overlay.add_child(_how_to_panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 36)
	margin.add_theme_constant_override("margin_right", 36)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 24)
	_how_to_panel.add_child(margin)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	margin.add_child(column)

	var kicker := Label.new()
	kicker.text = "RALLY CITY FIELD MANUAL"
	kicker.theme_type_variation = "PillLabel"
	kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	kicker.add_theme_color_override("font_color", ArcadeTheme.TEAL)
	column.add_child(kicker)

	var title := Label.new()
	title.text = "HOW TO PLAY"
	title.theme_type_variation = "TitleLabel"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 54)
	column.add_child(title)

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 28)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(columns)

	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 6)
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.add_child(left)
	left.add_child(_section_label("CONTROLS"))
	left.add_child(_key_row("W / S", "Move your paddle up and down"))
	left.add_child(_key_row("SPACE", "Smash — supercharge your next return"))
	left.add_child(_key_row("SHIFT", "Guard — soften the incoming ball"))
	left.add_child(_key_row("ESC", "Pause or resume the match"))

	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 6)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.add_child(right)
	right.add_child(_section_label("MATCH RULES"))
	right.add_child(_rule_line("11", "points wins a round"))
	right.add_child(_rule_line("+2", "win by at least two"))
	right.add_child(_rule_line("3", "rounds maximum — best of three"))
	right.add_child(_rule_line("2", "round wins takes the match"))

	var ability_row := HBoxContainer.new()
	ability_row.add_theme_constant_override("separation", 12)
	column.add_child(ability_row)
	ability_row.add_child(_ability_explain("SMASH", "Space", "A timed power hit. The ball leaves faster and hits harder. 5 second cooldown.", ArcadeTheme.YELLOW))
	ability_row.add_child(_ability_explain("GUARD", "Shift", "Hold to shield the return and slow the incoming ball. 6 second cooldown.", ArcadeTheme.TEAL))

	var footer := HBoxContainer.new()
	footer.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_child(footer)
	var close := Button.new()
	close.text = "GOT IT — LET'S RALLY"
	close.theme_type_variation = "PrimaryButton"
	close.custom_minimum_size = Vector2(320, 52)
	close.add_theme_font_size_override("font_size", 22)
	close.pressed.connect(_close_how_to_play)
	footer.add_child(close)


func _section_label(text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.theme_type_variation = "DisplayLabel"
	label.add_theme_font_size_override("font_size", 19)
	label.add_theme_color_override("font_color", ArcadeTheme.YELLOW)
	label.add_theme_constant_override("outline_size", 4)
	return label


func _key_row(key: String, description: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var key_label := Label.new()
	key_label.text = key
	key_label.theme_type_variation = "DisplayLabel"
	key_label.add_theme_font_size_override("font_size", 13)
	key_label.add_theme_color_override("font_color", ArcadeTheme.INK)
	key_label.add_theme_constant_override("outline_size", 0)
	key_label.add_theme_stylebox_override("normal", ArcadeTheme.keycap_style())
	key_label.custom_minimum_size = Vector2(92, 28)
	key_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	key_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(key_label)
	var text := Label.new()
	text.text = description
	text.theme_type_variation = "MutedLabel"
	text.add_theme_font_size_override("font_size", 13)
	text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(text)
	return row


func _rule_line(value: String, description: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	var number := Label.new()
	number.text = value
	number.theme_type_variation = "DisplayLabel"
	number.add_theme_font_size_override("font_size", 25)
	number.add_theme_color_override("font_color", ArcadeTheme.TEAL)
	number.custom_minimum_size = Vector2(42, 0)
	row.add_child(number)
	var text := Label.new()
	text.text = description
	text.theme_type_variation = "MutedLabel"
	text.add_theme_font_size_override("font_size", 13)
	text.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(text)
	return row


func _ability_explain(title: String, key: String, description: String, accent: Color) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.theme_type_variation = "DarkPanel"
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 9)
	margin.add_theme_constant_override("margin_bottom", 9)
	panel.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 2)
	margin.add_child(column)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	column.add_child(header)
	var name := Label.new()
	name.text = title
	name.theme_type_variation = "DisplayLabel"
	name.add_theme_font_size_override("font_size", 18)
	name.add_theme_color_override("font_color", accent)
	name.add_theme_constant_override("outline_size", 3)
	header.add_child(name)
	var key_label := Label.new()
	key_label.text = key
	key_label.theme_type_variation = "MutedLabel"
	key_label.add_theme_font_size_override("font_size", 10)
	key_label.add_theme_color_override("font_color", ArcadeTheme.INK)
	key_label.add_theme_stylebox_override("normal", ArcadeTheme.keycap_style(accent))
	header.add_child(key_label)
	var text := Label.new()
	text.text = description
	text.theme_type_variation = "MutedLabel"
	text.add_theme_font_size_override("font_size", 12)
	text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	column.add_child(text)
	return panel


func _open_how_to_play() -> void:
	if _leaving:
		return
	Sfx.play_sfx("click", -4.0, 1.0)
	_how_to_overlay.visible = true
	_how_to_panel.scale = Vector2(0.9, 0.9)
	_how_to_panel.pivot_offset = Vector2(432, 290)
	var tween := create_tween()
	tween.tween_property(_how_to_panel, "scale", Vector2.ONE, 0.26).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _close_how_to_play() -> void:
	Sfx.play_sfx("back", -6.0, 1.1)
	_how_to_overlay.visible = false


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_game") and _how_to_overlay.visible:
		_close_how_to_play()
		get_viewport().set_input_as_handled()


func _build_fade_overlay() -> void:
	_fade_overlay = ColorRect.new()
	_fade_overlay.color = Color(ArcadeTheme.INK_DEEP.r, ArcadeTheme.INK_DEEP.g, ArcadeTheme.INK_DEEP.b, 1.0)
	_fade_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_fade_overlay)


func _fade_in() -> void:
	var tween := create_tween()
	tween.tween_property(_fade_overlay, "color:a", 0.0, 0.45)
	tween.tween_callback(func() -> void: _fade_overlay.visible = false)
