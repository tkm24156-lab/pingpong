class_name Paddle
extends Node2D
## Vertical table-tennis paddle. The match controller drives its target.

const WIDTH := 28.0
const HEIGHT := 130.0

var side := 0
var accent := Color("#2EE6C8")
var is_player := true
var velocity_y := 0.0
var smash_active := false
var guard_active := false
var _time := 0.0
var _flash := 0.0
var _body_style: StyleBoxFlat
var _rim_style: StyleBoxFlat
var _shine_style: StyleBoxFlat
var _guard_style: StyleBoxFlat


func _ready() -> void:
	z_index = 6
	_body_style = ArcadeTheme._style(accent.darkened(0.1), accent.lightened(0.35), 13, 3, 8)
	_rim_style = ArcadeTheme._style(Color("#10122B"), accent, 15, 3, 4)
	_shine_style = ArcadeTheme._style(Color(1, 1, 1, 0.22), Color(0, 0, 0, 0), 8, 0, 0)
	_guard_style = ArcadeTheme._style(Color(0.18, 0.9, 0.78, 0.12), Color(0.45, 1.0, 0.9, 0.85), 18, 3, 0)


func get_half_width() -> float:
	return WIDTH * 0.5


func get_half_height() -> float:
	return HEIGHT * 0.5


func get_collision_rect() -> Rect2:
	return Rect2(position - Vector2(WIDTH * 0.5, HEIGHT * 0.5), Vector2(WIDTH, HEIGHT))


func move_to_target(target_y: float, speed: float, delta: float, bounds: Vector2) -> void:
	var old_y := position.y
	var clamped_target := clampf(target_y, bounds.x, bounds.y)
	var max_step := speed * delta
	var new_y := move_toward(position.y, clamped_target, max_step)
	position.y = new_y
	velocity_y = (new_y - old_y) / maxf(delta, 0.0001)


func hit_reaction(guard: bool, smash: bool) -> void:
	_flash = 1.0
	if guard:
		_guard_style.border_color = Color(1, 1, 1, 0.95)
	queue_redraw()


func _process(delta: float) -> void:
	_time += delta
	_flash = maxf(0.0, _flash - delta * 4.0)
	queue_redraw()


func _draw() -> void:
	var bob := sin(_time * 4.0) * 1.2
	var top_left := Vector2(-WIDTH * 0.5, -HEIGHT * 0.5 + bob)
	var rect := Rect2(top_left, Vector2(WIDTH, HEIGHT))

	if guard_active:
		var shield_rect := Rect2(
			Vector2(-WIDTH * 0.5 - 13.0, -HEIGHT * 0.5 - 14.0 + bob),
			Vector2(WIDTH + 26.0, HEIGHT + 28.0)
		)
		draw_style_box(_guard_style, shield_rect)
		for i in 3:
			var glow_alpha := 0.10 + 0.06 * sin(_time * 9.0 + i)
			var inner := shield_rect.grow(-(5.0 + i * 5.0))
			draw_style_box(ArcadeTheme._style(Color(0.2, 1.0, 0.9, glow_alpha), Color(0, 0, 0, 0), 16, 1, 0), inner)

	# Motion streaks.
	if absf(velocity_y) > 60.0:
		var direction := signf(velocity_y)
		for i in 3:
			var y := rect.position.y + 22.0 + i * 37.0 + bob
			var length := clampf(absf(velocity_y) * 0.045, 6.0, 24.0)
			draw_line(
				Vector2(-WIDTH * 0.5 - 12.0, y),
				Vector2(-WIDTH * 0.5 - 12.0 - length, y + direction * 4.0),
				Color(accent.r, accent.g, accent.b, 0.28),
				3.0,
				true
			)

	# Handle peeking from the center, then the blade.
	var handle_rect := Rect2(Vector2(-5.0, -HEIGHT * 0.5 - 20.0 + bob), Vector2(10.0, 26.0))
	draw_style_box(_rim_style, handle_rect)
	var grip_rect := handle_rect.grow(-3.0)
	draw_rect(grip_rect, Color("#F2A65A"))

	# Shadow and rim.
	draw_style_box(ArcadeTheme._style(Color(0, 0, 0, 0.32), Color(0, 0, 0, 0), 15, 0, 0), Rect2(rect.position + Vector2(5, 8), rect.size))
	draw_style_box(_rim_style, rect)
	var face_rect := rect.grow(-4.0)
	draw_style_box(_body_style, face_rect)

	# Glossy face and dot pattern.
	draw_style_box(_shine_style, Rect2(face_rect.position + Vector2(3, 6), Vector2(7, face_rect.size.y - 14)))
	for i in 4:
		var dot_y := face_rect.position.y + 24.0 + i * 26.0
		draw_circle(Vector2(face_rect.get_center().x + 2.0, dot_y), 2.2, Color(1, 1, 1, 0.16))
	draw_style_box(ArcadeTheme._style(Color(0, 0, 0, 0), accent.lightened(0.45), 9, 2, 0), face_rect.grow(-7.0))

	if smash_active:
		var pulse := 0.65 + 0.35 * sin(_time * 16.0)
		draw_style_box(
			ArcadeTheme._style(Color(1.0, 0.36, 0.45, 0.13), Color(1.0, 0.58, 0.2, 0.8 * pulse), 18, 3, 10),
			rect.grow(9.0)
		)
		for i in 4:
			var flame_y := rect.position.y + 12.0 + i * 31.0
			var side_x := (-1.0 if side == 0 else 1.0) * (WIDTH * 0.5 + 10.0)
			var tip := Vector2(side_x + (-1.0 if side == 0 else 1.0) * (10.0 + 5.0 * sin(_time * 19.0 + i)), flame_y + 7.0)
			var base := Vector2(side_x, flame_y - 8.0)
			draw_colored_polygon(PackedVector2Array([base, Vector2(side_x, flame_y + 14.0), tip]), Color(1.0, 0.55, 0.2, 0.55))

	if _flash > 0.0:
		draw_style_box(
			ArcadeTheme._style(Color(1, 1, 1, 0.2 * _flash), Color(1, 1, 1, 0.7 * _flash), 16, 2, 0),
			rect.grow(5.0)
		)
