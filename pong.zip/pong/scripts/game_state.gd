extends Node
## Persistent settings and shared match data.

signal difficulty_changed(difficulty_id: String)
signal sound_changed(enabled: bool)

const SETTINGS_PATH := "user://pong_panic.cfg"

const DIFFICULTIES := {
	"easy": {
		"label": "EASY",
		"tagline": "A relaxed rally. BOT-9000 has slow reflexes and makes mistakes.",
		"color": Color("#61E8A8"),
		"move_speed": 315.0,
		"reaction_time": 0.40,
		"error_px": 72.0,
		"prediction": false,
		"hesitation_chance": 0.22,
		"smash_chance": 0.0,
		"guard_chance": 0.0,
		"center_bias": 0.55,
	},
	"medium": {
		"label": "MEDIUM",
		"tagline": "A proper duel. Balanced reactions, aim, and a taste for attack.",
		"color": Color("#FFD447"),
		"move_speed": 440.0,
		"reaction_time": 0.21,
		"error_px": 32.0,
		"prediction": true,
		"hesitation_chance": 0.07,
		"smash_chance": 0.16,
		"guard_chance": 0.14,
		"center_bias": 0.40,
	},
	"hard": {
		"label": "HARD",
		"tagline": "Championship pressure. Lightning reactions and ruthless accuracy.",
		"color": Color("#FF6B8A"),
		"move_speed": 585.0,
		"reaction_time": 0.075,
		"error_px": 7.0,
		"prediction": true,
		"hesitation_chance": 0.012,
		"smash_chance": 0.32,
		"guard_chance": 0.24,
		"center_bias": 0.30,
	},
}

const PLAYER_NAME := "MAYA"
const AI_NAME := "BOT-9000"

var difficulty: String = "medium"
var sound_enabled: bool = true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_input_actions()
	_load_settings()


func set_difficulty(value: String) -> void:
	if not DIFFICULTIES.has(value):
		return
	difficulty = value
	_save_settings()
	difficulty_changed.emit(value)


func get_difficulty_id() -> String:
	return difficulty


func get_ai_profile() -> Dictionary:
	return DIFFICULTIES[difficulty].duplicate(true)


func get_difficulty_title() -> String:
	return DIFFICULTIES[difficulty]["label"]


func get_difficulty_tagline() -> String:
	return DIFFICULTIES[difficulty]["tagline"]


func get_difficulty_color() -> Color:
	return DIFFICULTIES[difficulty]["color"]


func set_sound_enabled(enabled: bool) -> void:
	sound_enabled = enabled
	_save_settings()
	sound_changed.emit(enabled)


func toggle_sound() -> bool:
	set_sound_enabled(not sound_enabled)
	return sound_enabled


func _load_settings() -> void:
	var config := ConfigFile.new()
	if config.load(SETTINGS_PATH) != OK:
		return
	var saved_difficulty: String = str(config.get_value("game", "difficulty", "medium"))
	if DIFFICULTIES.has(saved_difficulty):
		difficulty = saved_difficulty
	sound_enabled = bool(config.get_value("game", "sound_enabled", true))


func _save_settings() -> void:
	var config := ConfigFile.new()
	config.set_value("game", "difficulty", difficulty)
	config.set_value("game", "sound_enabled", sound_enabled)
	config.save(SETTINGS_PATH)


func _ensure_input_actions() -> void:
	_add_action("move_up", [KEY_W, KEY_UP], [KEY_W, KEY_UP])
	_add_action("move_down", [KEY_S, KEY_DOWN], [KEY_S, KEY_DOWN])
	_add_action("smash", [KEY_SPACE], [KEY_SPACE])
	_add_action("guard", [KEY_SHIFT], [KEY_SHIFT])
	_add_action("pause_game", [KEY_ESCAPE], [KEY_ESCAPE])
	_add_action("mute", [KEY_M], [KEY_M])


func _add_action(action: String, keycodes: Array, physical_keycodes: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	if not InputMap.action_get_events(action).is_empty():
		return
	for key in keycodes:
		var event := InputEventKey.new()
		event.keycode = key
		InputMap.action_add_event(action, event)
	for key in physical_keycodes:
		var event := InputEventKey.new()
		event.physical_keycode = key
		InputMap.action_add_event(action, event)
