# Pong Panic

A cartoon arcade table-tennis showdown built with **Godot 4.7 (GDScript)**.
You play Maya against BOT-9000 in a best-of-3 duel with **Smash** and **Guard** abilities.

## Run it

1. Install Godot 4.7 or newer (the project uses the GL Compatibility renderer).
2. Open `project.godot` in the editor, or run from a terminal:

```bash
godot --path .            # play
godot -e --path .         # open in the editor
```

## Controls

| Action | Key |
| --- | --- |
| Move paddle | `W` / `S` |
| Smash (attack) | `Space` |
| Guard (defend) | `Shift` |
| Pause / resume | `Esc` |

Menu: `A`/`D` or arrow keys to pick a difficulty, `Enter` / click to start.

## Rules

- A point is scored when the opponent fails to return the ball.
- A round is won at **11 points with a 2-point lead** (no hard cap, deuce continues).
- The match is **best of 3**: first to 2 rounds wins.
- The ball starts each round at base speed and accelerates every rally, up to a hard cap.
- Ball speed, scores and cooldowns reset when a new round starts.

## Mechanics

- **Smash** — a short window (`0.38 s`) that fires the ball back faster. Cooldown `5 s`.
- **Guard** — a `1.35 s` defensive stance that absorbs pace, so the return comes back slower and is easier to control. Cooldown `6 s`.
- The HUD shows both abilities with live cooldown bars, plus a ball-speed meter that turns hot as the rally speeds up.
- The AI uses the same abilities on its own cooldowns, scaled by difficulty.

## AI difficulty

| Difficulty | Behaviour |
| --- | --- |
| Easy | Slow reactions, wide aim error, frequent mistakes |
| Medium | Balanced reaction speed and accuracy |
| Hard | Fast reactions, tight aim, aggressive smashes |

The choice is persisted in `user://` config, so it survives restarts.

## Project layout

```
project.godot          engine config, autoloads (GameState, Sfx), input map
scenes/
  main_menu.tscn       animated title showdown + difficulty picker
  game.tscn            match controller with the arena
scripts/
  game.gd              match state machine, scoring, ability resolution
  ball.gd  paddle.gd   ball physics and paddle movement
  ai_controller.gd     difficulty-driven opponent
  arena.gd             court, backdrop and decoration
  menu_showdown.gd     menu character attack animations
  character_view.gd    sprite-based character animation
  fx_layer.gd          hit bursts, trails and screen shake
  game_state.gd        autoload: difficulty + saved settings
  audio_manager.gd     autoload: music and one-shot SFX
  core/                match_rules.gd (scoring) and cooldown_ability.gd
  ui/                  hud, pause menu, results screen, ability cards, theme
assets/
  audio/  fonts/  sprites/characters/{maya,bot}/
tests/
  test_runner.gd       headless logic tests
  visual_capture.gd    windowed screenshot smoke test
```

## Tests

```bash
# 56 headless logic checks (rules, scoring, abilities, pause, victory)
godot --headless --path . -s res://tests/test_runner.gd

# renders menu / gameplay / pause / victory screenshots into .artifacts/
godot --path . --resolution 1280x720 -s res://tests/visual_capture.gd
```

## Credits and licenses

| Asset | Source | License |
| --- | --- | --- |
| Character art (`maya`, `bot`) | [Kenney — Toon Characters Pack 1](https://kenney.nl/assets/toon-characters-1) | CC0 1.0 |
| Sound effects and music | [Kenney audio packs](https://kenney.nl/assets) | CC0 1.0 |
| Luckiest Guy (display font) | Fonts by Astigmatic | Apache License 2.0 |
| Nunito (body font) | The Nunito Project Authors | SIL Open Font License 1.1 |

Full license texts ship next to the assets: `assets/audio/LICENSE-KENNEY.txt`,
`assets/fonts/LICENSE-LuckiestGuy.txt`, `assets/fonts/LICENSE-Nunito.txt`,
`assets/sprites/characters/LICENSE-KENNEY.txt`.
Everything else — court, effects, UI and code — is original to this project.
