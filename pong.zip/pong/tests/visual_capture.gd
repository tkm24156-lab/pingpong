extends SceneTree
## Windowed visual smoke test. Saves PNG captures to res://.artifacts/.
## Run:
##   Godot --path . -s res://tests/visual_capture.gd

var _output_dir := "res://.artifacts"


func _initialize() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(_output_dir))
	change_scene_to_file("res://scenes/main_menu.tscn")
	_run_sequence()


func _run_sequence() -> void:
	await create_timer(2.1).timeout
	await _save("01_menu")
	change_scene_to_file("res://scenes/game.tscn")
	await create_timer(4.0).timeout
	await _save("02_gameplay")
	var game := current_scene
	game._pause_match()
	await create_timer(0.35).timeout
	await _save("03_pause")
	game._resume_match()
	game._match_over_menu.show_result(true, 2, 1, {
		"longest_rally": 14,
		"smashes": 6,
		"blocks": 3,
	})
	await create_timer(0.6).timeout
	await _save("04_victory")
	quit(0)


func _save(label: String) -> void:
	await RenderingServer.frame_post_draw
	await process_frame
	var image := root.get_texture().get_image()
	var path := ProjectSettings.globalize_path("%s/%s.png" % [_output_dir, label])
	var error := image.save_png(path)
	print("CAPTURE %s -> %s (%s)" % [label, path, error_string(error)])
