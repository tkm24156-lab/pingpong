extends SceneTree
## Headless test suite. Run:
##   Godot --headless --path . -s res://tests/test_runner.gd

var _failures := 0
var _checks := 0
var _game: Node


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	print("========================================")
	print(" PONG PANIC — HEADLESS TEST SUITE")
	print("========================================")
	_test_match_rules()
	_test_cooldowns()
	await _test_game_scene()
	_test_goal_scoring()
	print("----------------------------------------")
	print("Checks: %d   Failures: %d" % [_checks, _failures])
	if _failures == 0:
		print("RESULT: ALL TESTS PASSED")
	else:
		print("RESULT: %d TEST(S) FAILED" % _failures)
	quit(0 if _failures == 0 else 1)


func _check(condition: bool, label: String) -> void:
	_checks += 1
	if condition:
		print("  PASS  %s" % label)
	else:
		_failures += 1
		printerr("  FAIL  %s" % label)


func _test_match_rules() -> void:
	print("\n[SCORING RULES]")
	_check(MatchRules.round_is_won(11, 9), "11–9 wins the round")
	_check(not MatchRules.round_is_won(11, 10), "11–10 does not win the round")
	_check(MatchRules.round_is_won(12, 10), "12–10 wins the round by two")
	_check(not MatchRules.round_is_won(10, 8), "10–8 is not a round win")
	_check(MatchRules.round_is_won(0, 11), "AI can win a round")
	_check(not MatchRules.round_is_won(13, 12), "13–12 still requires a two-point margin")
	_check(MatchRules.round_is_won(20, 18), "long deuce rounds can finish")
	_check(MatchRules.is_deuce(10, 10), "10–10 is deuce")
	_check(MatchRules.is_deuce(12, 12), "12–12 is deuce")
	_check(not MatchRules.is_deuce(10, 9), "10–9 is not deuce")
	_check(MatchRules.point_status(10, 10) == "deuce", "point status reports deuce")
	_check(MatchRules.point_status(11, 10) == "advantage_player", "point status reports player advantage")
	_check(MatchRules.point_status(10, 11) == "advantage_ai", "point status reports AI advantage")
	_check(MatchRules.point_status(10, 9) == "game", "10–9 reports game point")
	_check(MatchRules.point_status(5, 4) == "normal", "early score reports normal")
	_check(MatchRules.match_is_won(2, 0), "two round wins take the match")
	_check(MatchRules.match_is_won(2, 1), "2–1 takes the match")
	_check(not MatchRules.match_is_won(1, 1), "1–1 needs a deciding round")
	_check(not MatchRules.match_is_won(0, 0), "0–0 is not a match win")
	_check(MatchRules.match_point_for(1, 0, 10, 9), "match point detected for the player")
	_check(not MatchRules.match_point_for(0, 0, 10, 9), "game point is not match point in round one")
	_check(MatchRules.match_point_against(0, 1, 9, 10), "match point detected against the player")
	_check(not MatchRules.match_point_against(0, 0, 9, 10), "AI game point is not match point in round one")


func _test_cooldowns() -> void:
	print("\n[ABILITY COOLDOWNS]")
	var ability := CooldownAbility.new(1.0, 0.2)
	_check(ability.is_ready(), "ability starts ready")
	_check(ability.trigger(), "ability triggers when ready")
	_check(not ability.is_ready(), "ability is not ready while active")
	_check(not ability.trigger(), "ability cannot retrigger while active")
	ability.tick(0.25)
	_check(not ability.is_active(), "active window expires")
	_check(not ability.is_ready(), "cooldown persists after active window")
	ability.tick(0.8)
	_check(ability.is_ready(), "cooldown completes")
	_check(ability.trigger(), "ability can be used again after cooldown")
	ability.reset()
	_check(ability.is_ready(), "reset makes ability ready")


func _test_game_scene() -> void:
	print("\n[GAME SCENE]")
	var game_scene: PackedScene = load("res://scenes/game.tscn")
	_check(game_scene != null, "game scene loads")
	_game = game_scene.instantiate()
	root.add_child(_game)
	await create_timer(3.2).timeout

	var state: Dictionary = _game.get_debug_state()
	_check(state["state"] == 3, "match reaches PLAYING state after intro and serve")
	_check(state["player_score"] == 0 and state["ai_score"] == 0, "match starts at 0–0")
	_check(state["round"] == 1, "match starts at round 1")
	_check(state["ball_active"], "ball is live once the match starts")
	_check(state["ball_speed"] >= 430.0, "serve ball speed starts at base speed or above")
	_check(_game._ball.visible, "ball is visible during play")
	_check(_game._hud != null and _game._pause_menu != null and _game._match_over_menu != null, "HUD, pause, and results layers exist")

	# Freeze automatic movement while directly testing collisions.
	_game._state = 4 # POINT
	_game._ball.set_active(false)
	_game._player_paddle.position = Vector2(170, 380)
	_game._ball.position = Vector2(190, 380)
	_game._ball.velocity = Vector2(-600, 0)
	_game._ball.set_active(true)
	_game._smash.reset()
	_game._guard.reset()

	var before_smash := absf(_game._ball.velocity.x)
	var smash_triggered: bool = _game._smash.trigger()
	_check(smash_triggered, "smash activates when ready")
	_game._resolve_paddle_collision()
	var after_smash := absf(_game._ball.velocity.x)
	_check(_game._smashes == 1, "successful smash increments stats")
	_check(after_smash > before_smash, "smash increases outgoing ball speed")
	_check(after_smash <= 980.0, "smash respects the maximum ball speed")

	_game._smash.reset()
	_game._guard.reset()
	_game._player_paddle.position = Vector2(170, 380)
	_game._ball.position = Vector2(190, 380)
	_game._ball.velocity = Vector2(-620, 0)
	_game._ball.set_active(true)
	var before_guard := absf(_game._ball.velocity.x)
	_game._guard.trigger()
	_game._resolve_paddle_collision()
	var after_guard := absf(_game._ball.velocity.x)
	_check(_game._blocks == 1, "successful guard increments stats")
	_check(after_guard < before_guard, "guard reduces outgoing ball speed")

	# Ball speed ceiling.
	_game._player_paddle.position = Vector2(170, 380)
	_game._ball.position = Vector2(190, 380)
	_game._ball.velocity = Vector2(-960, 0)
	_game._ball.set_active(true)
	_game._smash.reset()
	_game._guard.reset()
	_game._smash.trigger()
	_game._resolve_paddle_collision()
	_check(absf(_game._ball.velocity.x) <= 980.0, "ball speed never exceeds the cap")

	# Pause and resume.
	_game._state = 3 # PLAYING
	_game._pause_match()
	_check(paused, "pause pauses the scene tree")
	_check(_game._pause_menu.visible, "pause overlay is visible")
	_game._resume_match()
	_check(not paused, "resume unpauses the scene tree")
	_check(not _game._pause_menu.visible, "pause overlay hides on resume")

	# Results screen.
	_game._state = 3
	_game._player_rounds = 2
	_game._ai_rounds = 0
	_game._finish_match(true)
	await create_timer(1.1).timeout
	_check(_game._match_over_menu.visible, "victory screen appears when the match ends")
	_check(_game.get_debug_state()["state"] == 6, "match enters MATCH_OVER state")
	_check(not paused, "match over leaves the tree unpaused")


func _test_goal_scoring() -> void:
	print("\n[GOAL SCORING]")
	if not is_instance_valid(_game):
		return
	_game._state = 3 # PLAYING
	_game._player_score = 0
	_game._ai_score = 0
	_game._match_over_menu.visible = false
	_game._ball.position = Vector2(1215, 380)
	_game._ball.velocity = Vector2(500, 0)
	_game._ball.set_active(true)
	_game._resolve_goal()
	var state: Dictionary = _game.get_debug_state()
	_check(state["player_score"] == 1, "ball leaving the AI side scores for the player")
	_check(not state["ball_active"], "ball deactivates after a point")


func _exit_tree() -> void:
	pass
